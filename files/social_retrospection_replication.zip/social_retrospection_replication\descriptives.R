# Descriptive Statistics
# Produces appendix tables of descriptive statistics
#
# All tables saved as LaTeX to tables/
# Sample: non-missing on Model 1 IVs (prop_disagree_w5a, prop_disagree_w3a, city5)

# Setup ---------------------------------------------------------------

library(tidyverse)
library(xtable)


# Helper: Publication-quality LaTeX table via xtable ------------------
#
# Numbers are pre-formatted in R to `col_digits` decimal places, then
# output to right-aligned ("r") columns. This produces visually
# decimal-aligned columns without requiring \usepackage{dcolumn}.
#
# col_digits: integer vector, one value per column in df
#   - character columns get left ("l") alignment regardless of value
#   - 0  => integer formatting, right-aligned
#   - n  => n decimal places, right-aligned
# note: optional string written as a \footnotesize footnote below the table
#
# Requires in the LaTeX document preamble:
#   \usepackage{booktabs}

save_latex_table <- function(df, file, caption, label, col_digits, note = NULL) {

  n_cols <- ncol(df)
  stopifnot(length(col_digits) == n_cols)

  is_char <- sapply(df, is.character)

  # Pre-format numeric columns as strings with fixed decimal places
  df_fmt <- df
  for (i in seq_len(n_cols)) {
    if (!is_char[i]) {
      df_fmt[[i]] <- sprintf(paste0("%.", col_digits[i], "f"), df[[i]])
    }
  }

  # Alignment: character cols -> "l", all numeric cols -> "r"
  xtab_align <- c("l", ifelse(is_char, "l", "r"))

  # All cols are now character strings; suppress xtable's own number formatting
  xtab_digits <- rep(0L, n_cols + 1L)

  tbl <- xtable(df_fmt, caption = caption, label = label,
                digits = xtab_digits, align = xtab_align)

  # Capture xtable output as a string for post-processing
  latex_out <- paste(
    capture.output(
      print(tbl,
            include.rownames       = FALSE,
            booktabs               = TRUE,
            caption.placement      = "top",
            sanitize.text.function = identity)
    ),
    collapse = "\n"
  )

  # Insert minipage note between \end{tabular} and \end{table}
  # (add.to.row puts content inside the tabular; minipage must be outside it)
  if (!is.null(note)) {
    minipage <- paste0(
      "\\begin{minipage}{.80\\textwidth}\n",
      "  \\singlespacing \\small\n",
      "  \\textbf{Note:} ", note, "\n",
      "\\end{minipage}"
    )
    latex_out <- sub(
      "\\end{table}",
      paste0(minipage, "\n\\end{table}"),
      latex_out,
      fixed = TRUE
    )
  }

  # Write preamble comment then the table
  writeLines(
    c("% Required LaTeX package: \\usepackage{booktabs}", "", latex_out),
    con = file
  )

  cat("Saved:", file, "\n")
}


# Load Data -----------------------------------------------------------

# analysis_dat.Rds is created by candidate_switching.R
# It adds lula_eval_w5, vote_lula, and recodes city5/pid vars as factors
dat <- read_rds("analysis_dat.Rds")


# Define Analysis Sample ----------------------------------------------
# Restrict to observations non-missing on Model 1 IVs

m1_sample <- dat |>
  drop_na(prop_disagree_w5a, prop_disagree_w3a, city5, switch1) |>
  mutate(
    # pid vars were saved as factors; convert back to 0/1 numeric for summary stats
    pid_yes_w3 = as.numeric(as.character(pid_yes_w3)),
    pid_yes_w5 = as.numeric(as.character(pid_yes_w5)),
    # Voter type factor with clean labels for table columns
    vote_lula  = factor(vote_lula,
                        levels = c("Lula",         "Other"),
                        labels = c("Lula Voters",  "Other Voters"))
  )

cat("Model 1 sample N =", nrow(m1_sample), "\n")


# Table A1: Overall Summary Statistics --------------------------------
# Mean, SD, min, max, and N for all model variables

tbl_a1_data <- m1_sample |>
  transmute(
    # Outcome
    `Candidate Switching`           = switch1,
    # Network disagreement (key IVs)
    `Prop. Disagreeing (t)`         = prop_disagree_w5a,
    `Prop. Disagreeing (t-1)`       = prop_disagree_w3a,
    # Network composition: share of discussants supporting Lula
    # (Addresses Reviewer 3: do Lula-voter networks have more Lula supporters?)
    `Prop. Lula in Network (t)`     = prop_lula_w5,
    `Prop. Lula in Network (t-1)`   = prop_lula_w3,
    # Network structure controls
    `Network Diversity (t)`         = het_w5,
    `Network Diversity (t-1)`       = het_w3,
    `Num. Discussants (t)`          = n_discuss_w5,
    `Num. Discussants (t-1)`        = n_discuss_w3,
    `Network Change`                = net_volatility,
    # Individual-level controls
    `Party ID (t)`                  = pid_yes_w5,
    `Party ID (t-1)`                = pid_yes_w3,
    `Lula Performance Eval. (t)`    = lula_eval_w5,
    `Media Consumption (t-1)`       = media_w3,
    `Political Knowledge (t-1)`     = knowledge_w3
  )

# Build summary data frame: one row per variable
tbl_a1_df <- tbl_a1_data |>
  pivot_longer(everything(), names_to = "Variable", values_to = "value") |>
  group_by(Variable) |>
  summarise(
    N    = sum(!is.na(value)),
    Mean = mean(value, na.rm = TRUE),
    SD   = sd(value,   na.rm = TRUE),
    Min  = min(value,  na.rm = TRUE),
    Max  = max(value,  na.rm = TRUE),
    .groups = "drop"
  ) |>
  # Preserve original variable order
  mutate(Variable = factor(Variable, levels = names(tbl_a1_data))) |>
  arrange(Variable) |>
  mutate(Variable = as.character(Variable))

save_latex_table(
  df         = tbl_a1_df,
  file       = "tables/table_a1_summary_stats.tex",
  caption    = "Summary Statistics (Model 1 Analysis Sample)",
  label      = "tab:sumstats",
  col_digits = c(0, 0, 2, 2, 2, 2),   # Variable(char->l), N(int->r), Mean/SD/Min/Max(D{.}{.}{2})
  note       = paste0(
    "Sample restricted to observations non-missing on Model 1 variables ",
    "(N = ", nrow(tbl_a1_data), "). ",
    "Prop.\\ Lula in Network is the share of a respondent's discussants who support Lula."
  )
)


# Table A2: Summary Statistics by Voter Type --------------------------
# Compares Lula vs. Other voters on all model variables
# Directly addresses Reviewer 3's question: are Lula-voter networks more
# Lula-dominated? If networks of Lula voters have much higher prop_lula,
# it would suggest composition (not disagreement per se) drives effects.

tbl_a2_data <- m1_sample |>
  filter(!is.na(vote_lula)) |>   # drop the small share missing vote choice
  transmute(
    `Candidate Switching`           = switch1,
    `Prop. Disagreeing (t)`         = prop_disagree_w5a,
    `Prop. Disagreeing (t-1)`       = prop_disagree_w3a,
    `Prop. Lula in Network (t)`     = prop_lula_w5,
    `Prop. Lula in Network (t-1)`   = prop_lula_w3,
    `Network Diversity (t)`         = het_w5,
    `Network Diversity (t-1)`       = het_w3,
    `Num. Discussants (t)`          = n_discuss_w5,
    `Num. Discussants (t-1)`        = n_discuss_w3,
    `Network Change`                = net_volatility,
    `Party ID (t)`                  = pid_yes_w5,
    `Party ID (t-1)`                = pid_yes_w3,
    `Lula Performance Eval. (t)`    = lula_eval_w5,
    `Media Consumption (t-1)`       = media_w3,
    `Political Knowledge (t-1)`     = knowledge_w3,
    `Voter Type`                    = vote_lula
  )

# Helper: mean (SD) by group for each variable
group_summary <- function(data, group_label) {
  data |>
    filter(`Voter Type` == group_label) |>
    select(-`Voter Type`) |>
    pivot_longer(everything(), names_to = "Variable", values_to = "value") |>
    group_by(Variable) |>
    summarise(
      Mean = mean(value, na.rm = TRUE),
      SD   = sd(value,   na.rm = TRUE),
      N    = sum(!is.na(value)),
      .groups = "drop"
    )
}

lula_summ  <- group_summary(tbl_a2_data, "Lula Voters")
other_summ <- group_summary(tbl_a2_data, "Other Voters")

# Merge and compute raw difference in means
tbl_a2_df <- left_join(lula_summ, other_summ, by = "Variable", suffix = c("_L", "_O")) |>
  mutate(Diff = Mean_L - Mean_O) |>
  # Restore variable order (drop Voter Type from levels)
  mutate(Variable = factor(Variable, levels = names(tbl_a2_data)[names(tbl_a2_data) != "Voter Type"])) |>
  arrange(Variable) |>
  mutate(Variable = as.character(Variable)) |>
  select(Variable, `Lula Mean` = Mean_L, `Lula SD` = SD_L,
         `Other Mean` = Mean_O, `Other SD` = SD_O, Diff)

save_latex_table(
  df         = tbl_a2_df,
  file       = "tables/table_a2_summary_by_votertype.tex",
  caption    = "Summary Statistics by Voter Type (Model 1 Analysis Sample)",
  label      = "tab:sumstats_bygroup",
  col_digits = c(0, 2, 2, 2, 2, 2),   # Variable(char->l), all numeric cols -> D{.}{.}{2}
  note       = paste0(
    "Sample restricted to observations non-missing on Model 1 variables. ",
    "Prop.\\ Lula in Network measures the fraction of discussants supporting Lula, ",
    "allowing comparison of network composition across voter groups. ",
    "Diff.\\ is the raw difference in group means (Lula minus Other)."
  )
)


# Date Stuff ------------------------------


# Make Dates a Date Variable
dat <- dat |> 
  mutate(across(starts_with("date"), ~dmy(.x)))


dat |> 
  dplyr::select(date3, date5) |> 
  map(summary)


# Five observations asked on or after first debate
dat |> 
  filter(date5 > "2006-08-13") |> 
  dplyr::select(pres_vote_w3, pres_vote_w5) |> 
  na.omit() |> 
  nrow()


# Other Descriptives -------------------------


# Get data from m2
m1_dat <-  dat |> 
  drop_na(switch1, prop_disagree_w5a, prop_disagree_w3a) |> 
  dplyr::select(switch1, prop_disagree_w5a, prop_disagree_w3a, n_discuss_w5,
                n_discuss_w3, het_w5, het_w3, net_volatility,
                pid_yes_w3,pid_yes_w5, lula_eval_w5,
                city5, date5)


nrow(m1_dat)  # 941 non-missing obs 


# Number of disagreeing partners
summary(m1_dat$prop_disagree_w3a)
summary(m1_dat$prop_disagree_w5a)


# Percent with at least 1 disagreeing partner
m1_dat$at_least_one <- if_else(m1_dat$prop_disagree_w3a > 0, 1, 0)
sum(m1_dat$at_least_one)/nrow(m1_dat)


m1_dat$at_least_one_w5 <- if_else(m1_dat$prop_disagree_w5a > 0, 1, 0)
sum(m1_dat$at_least_one_w5)/nrow(m1_dat)




# Number of switchers in full dataset 
table(na.omit(dat$switch1))


# Number of discussion partners
summary(m1_dat$n_discuss_w5)
summary(m1_dat$n_discuss_w3)


# Percent with party ID
prop.table(table(m1_dat$pid_yes_w3)) # wave 3
prop.table(table(m1_dat$pid_yes_w5)) # wave 5




m1_dat |> 
  filter(date5 > "2006-07-31") |> 
  nrow()



