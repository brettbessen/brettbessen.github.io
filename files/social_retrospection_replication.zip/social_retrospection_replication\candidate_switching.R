# Analysis of Inter-Party Candidate Switching
## Runs Models, Outputs to Latex
## Plots Predictions
## Runs Sensitivity Analysis (Appendix)

# Setup -----------------------------

library(dplyr)
library(ggplot2)
library(readr)
library(ggpubr)
library(performance)
library(marginaleffects)
library(psych)
library(texreg)
library(sensemakr)

#Read the cleaned and recoded data. 
#Recodes are done in `brazilnet_shaping.do`.
dat <- read_csv("brazilnet_data_v2.csv")


# Minor Recodes ---------------------------

# Evaluation of Lula Index
# alpha = 0.82
dat |> 
  dplyr::select(corrupt_therm_w5, inflation_therm_w5,
         jobs_therm_w5, crime_therm_w5) |> 
  na.omit() |> 
  psych::alpha()


# Lula Performance Eval: Make Mean Index 
dat <- dat |>
  mutate(
    lula_eval_w5 = (corrupt_therm_w5 +
      inflation_therm_w5 +
      jobs_therm_w5 +
      crime_therm_w5) / 4
  )


# Recode vote lula 
dat <- dat  |>  
  mutate(vote_lula = case_match(vote_lula_w3,
                                1 ~ "Lula",
                                0 ~ "Other"))

# Make pid a factor
dat <- dat |> 
  mutate(
    city5      = factor(city5),
    pid_yes_w5 = factor(pid_yes_w5),
    pid_yes_w3 = factor(pid_yes_w3)
  )

# Save for Later Analyses
readr::write_rds(dat, "analysis_dat.Rds")

# Transition Models ----------------------

## Model 1 ----------------------------------------

# Model 1 IVs
m1_vars <- c("prop_disagree_w5a", "prop_disagree_w3a", 
             "city5")

# Model 1 - Lula
m1_lula <- glm(
  reformulate(m1_vars, response = "switch1"),
  family = binomial(link = "logit"), 
  data = subset(dat, vote_lula == "Lula")
)

# Model 1 - Others
m1_others <- glm(
  reformulate(m1_vars, response = "switch1"), 
  family = binomial(link = "logit"), 
  data = subset(dat, vote_lula == "Other")
)

## Model 2 -----------------------------------

# Model 2 IVs
m2_vars <- union(m1_vars, c("n_discuss_w5", "n_discuss_w3", "het_w5", "het_w3",
                            "net_volatility", "pid_yes_w5", "pid_yes_w3", 
                            "lula_eval_w5"))

# Model 2 -- Lula Voters
m2_lula <- glm(
  reformulate(m2_vars, response = "switch1"),
  family = binomial(link = "logit"), 
  data = subset(dat, vote_lula == "Lula")
)

# Model 3 -- Other Voters 
m2_others <- glm(
  reformulate(m2_vars, response = "switch1"),
  family = binomial(link = "logit"), 
  data = subset(dat, vote_lula == "Other")
)


## Model 3 ---------------------------------------------------

# Model 3 IVs
m3_vars <- union(m2_vars, c("media_w3", "knowledge_w3"))

# Model 3 -- Lula Voters
m3_lula <- glm(
  reformulate(m3_vars, response = "switch1"),
  family = binomial(link = "logit"), 
  data = subset(dat, vote_lula == "Lula")
)

# Model 3 -- Other Voters 
m3_others <- glm(
  reformulate(m3_vars, response = "switch1"),
  family = binomial(link = "logit"), 
  data = subset(dat, vote_lula == "Other")
)

## Out to Latex ---------------------------------------------

coef_list <- list(
  "prop_disagree_w5a" = "Prop. Disagreeing$_{t}$",
  "prop_disagree_w3a" = "Prop. Disagreeing$_{t-1}$",
  "lula_eval_w5" = "Performance Evaluation$_{t}$",
  "n_discuss_w5"  = "Num. Disscussants$_{t}$",
  "n_discuss_w3" = "Num. Disscussants$_{t-1}$",
  "het_w5"  =  "Network Diversity$_{t}$",
  "het_w3" =  "Network Diversity$_{t-1}$", 
  "net_volatility" = "Network Change",
  "pid_yes_w51" = "Party Identity$_{t}$", 
  "pid_yes_w31" = "Party Identity$_{t-1}$", 
  "media_w3" = "Media Consumption$_{t-1}$",
  "knowledge_w3" = "Political Knowledge$_{t-1}$",
  "(Intercept)" = "Intercept"
)


capt <- "Models of inter-party candidates switching between October 2002 and July 2006.  The dependent is a one if a respondent switched parties and a zero otherwise."

texreg(list("Lula Voters" = m1_lula, "Other Voters" = m1_others, 
            "Lula Voters" = m2_lula,  "Other Voters" = m2_others,
            "Lula Voters" = m3_lula,  "Other Voters" = m3_others),
       caption = capt,
       caption.above = T,
       label = "tab:switching",
       custom.coef.map = coef_list, 
       include.bic = F,
       include.deviance = F, 
       dcolumn = F)


# Equivalent interaction models ------------------------

## Model 1a -------------------------------------

m1a_rhs <- paste0("(", paste(m1_vars, collapse = " + "), ") * factor(vote_lula)")

m1a_fit <- glm(
  reformulate(m1a_rhs, response = "switch1"),
  family = binomial(link = "logit"), 
  data = dat
)

nobs(m1a_fit)
performance_aic(m1a_fit)
performance_pcp(m1a_fit, method = "Gelman-Hill")

## Model 2a ---------------------------------------------

m2a_rhs <- paste0("(", paste(m2_vars, collapse = " + "), ") * factor(vote_lula)")

m2a_fit <- glm(
  reformulate(m2a_rhs, response = "switch1"),
  family = binomial(link = "logit"),
  data = dat
  )

nobs(m2a_fit)
performance_aic(m2a_fit)
performance_pcp(m2a_fit, method = "Gelman-Hill")

## Model 3a ---------------------------------------------

m3a_rhs <- paste0("(", paste(m3_vars, collapse = " + "), ") * factor(vote_lula)")

m3a_fit <- glm(
  reformulate(m3a_rhs, response = "switch1"),
  family = binomial(link = "logit"),
  data = dat
)


nobs(m3a_fit)
performance_aic(m3a_fit)
performance_pcp(m3a_fit, method = "Gelman-Hill")


# Plot Predictions --------------------------

preds1 <- predictions(m3a_fit, newdata = datagrid(
  prop_disagree_w5a = seq(0, 1, .1),
  vote_lula = c("Lula", "Other")
))

preds1 <- preds1 |> 
  dplyr::select(prop_disagree_w5a, vote_lula, estimate, 
                conf.low, conf.high) |> 
  mutate(vote_lula = case_match(vote_lula,
                                "Lula" ~ "Lula Voter (Oct. 2002)",
                                "Other" ~ "Opposition Voter (Oct. 2002)"))

ggplot(preds1, aes(prop_disagree_w5a, estimate)) +
  geom_line() + 
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = .20, color = NA) +
  facet_grid(~ vote_lula) +
  labs(y = "Probability of Switching", x = "Network Disagreement", title = "Network Disagreement and Candidate Switching") +
  theme_pubr() +
  theme(plot.title = element_text(hjust = .5),
        axis.title = element_text(face = "bold"))


# ggsave("figs/switching_preds.pdf", height = 4, width = 6)
ggsave("figs/switching_preds.tif", height = 4, width = 6, dpi = 300)


# Interpretation -----------------------------------

# Get data from m3a
m3a_dat <-  dat |> 
  dplyr::select(switch1, prop_disagree_w5a, prop_disagree_w3a, n_discuss_w5,
         n_discuss_w3, het_w5, het_w3, net_volatility,
         pid_yes_w3,pid_yes_w5, lula_eval_w5,
         city5, media_w3, knowledge_w3) |> 
  na.omit()

# Effect of prop-disagree 

# One sd increase 
sd(m3a_dat$prop_disagree_w5a)
preds_dis <-  predictions(m3a_fit, 
                          newdata = datagrid(prop_disagree_w5a = c(0, 0.33),
                                             vote_lula = c("Lula", "Other")
                          ))  

preds_dis <- preds_dis |> 
  dplyr::select(prop_disagree_w5a, vote_lula, estimate) |>
  arrange(vote_lula)

preds_dis

preds_dis$estimate[2] - preds_dis$estimate[1] # lula supporters
preds_dis$estimate[4] - preds_dis$estimate[3] # opposition supporters


# Network volatility 
summary(m3a_dat$net_volatility)
sd(m3a_dat$net_volatility)

# One SD increase 
preds_vol <- predictions(m3a_fit, newdata = datagrid(vote_lula = c("Lula", "Other"),
                                                     net_volatility = c(.48, .74)))

preds_vol <- preds_vol |> 
  dplyr::select(estimate, vote_lula, net_volatility) |> 
  arrange(vote_lula)

preds_vol$estimate[2] - preds_vol$estimate[1]

preds_vol$estimate[4] - preds_vol$estimate[3]


# Performance Evaluations 
mean(m3a_dat$lula_eval_w5)
mean(m3a_dat$lula_eval_w5) + sd(m3a_dat$lula_eval_w5) 

eval_preds <- predictions(m3a_fit, newdata = datagrid(lula_eval_w5 = c(4.33,  6.86), 
                                                      vote_lula = c("Lula"))) |> 
  dplyr::select(estimate, lula_eval_w5)

eval_preds$estimate[2] - eval_preds$estimate[1]

# Partisanship 
pid_preds <- predictions(m3a_fit, newdata = datagrid(vote_lula = c("Lula"),
                                                     pid_yes_w3 = c(0,1),
                                                     pid_yes_w5 = c(0,1))) |> 
  dplyr::select(estimate, pid_yes_w3, pid_yes_w5)


# Sensitivity Analysis  --------------------------------

# Model 3 -- Lula Voters
m3_lula_ols <- lm(
  reformulate(m3_vars, response = "switch1"),
  data = subset(dat, vote_lula == "Lula")
)

# Model 2 -- Lula Voters
m3_other_ols <- lm(
  reformulate(m3_vars, response = "switch1"),
  data = subset(dat, vote_lula == "Other")
)


texreg(list("Lula Voters" = m3_lula_ols,
            "Other Voters" = m3_other_ols),
       caption = capt,
       caption.above = T,
       label = "tab:switching",
       custom.coef.map = coef_list, 
       include.bic = F,
       include.deviance = F)



sensitivity_lula <- sensemakr(model = m3_lula_ols, 
                              treatment = "prop_disagree_w5a", 
                              benchmark_covariates = "lula_eval_w5",
                              kd = 1:3,
                              ky = 1:3, 
                              q = 1,
                              alpha = 0.05, 
                              reduce = TRUE)

sensitivity_others <- sensemakr(model = m3_other_ols, 
                                treatment = "prop_disagree_w5a", 
                                benchmark_covariates = "knowledge_w3",
                                kd = 1:3,
                                ky = 1:3, 
                                q = 1,
                                alpha = 0.05, 
                                reduce = TRUE)

ovb_minimal_reporting(sensitivity_lula)
ovb_minimal_reporting(sensitivity_others)


# Plot and Save 

# Save sensitivity_lula plot
pdf("figs/sensitivity_lula.pdf", height = 4, width = 4)
plot(sensitivity_lula)
dev.off()

# Save sensitivity_lula plot with t-value
pdf("figs/sensitivity_lula_t_value.pdf", height = 4, width = 4)
plot(sensitivity_lula, sensitivity.of = "t-value")
dev.off()

# Save sensitivity_others plot
pdf("figs/sensitivity_others.pdf", height = 4, width = 4)
plot(sensitivity_others)
dev.off()

# Save sensitivity_others plot with t-value
pdf("figs/sensitivity_others_t_value.pdf", height = 4, width = 4)
plot(sensitivity_others, sensitivity.of = "t-value")
dev.off()
