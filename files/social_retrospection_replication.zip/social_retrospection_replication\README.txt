=====================================================================
REPLICATION PACKAGE

Social Retrospection: Conversation Networks, Performance
Evaluations, and Candidate Support

Brett Bessen
Journal of Elections, Public Opinion and Parties
=====================================================================


DATA AVAILABILITY
---------------------------------------------------------------------
The raw survey data are NOT included in this package. They are the
Two-City, Six-Wave Panel Survey, Brazil (2002, 2004, 2006), archived
at the Harvard Dataverse:

  https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/XSCFX5

Before running the scripts:

  1. Download TwoCityPanelStudy.dta from the link above.
  2. Place it in this folder (alongside brazilnet_shaping.do).


FILES IN THIS PACKAGE
---------------------------------------------------------------------
  brazilnet_shaping.do              Stata: data preparation
  candidate_switching.R             Main candidate-switching models
  descriptives.R                    Descriptive statistics tables
  multinomial_and_mediation.R       Multinomial models and mediation
  performance_evals.R               Performance evaluation models
  plot_support_lula.R               Lula support time-series figure
  robustness.R                      Robustness checks
  brazil_discussant_retention.dta   Discussant retention data
  figs/                             Output folder for figures (empty)
  tables/                           Output folder for tables (empty)

In brazil_discussant_retention.dta, the variables discussant1,
discussant2, and discussant3 record, for each respondent's Wave 5
discussants, whether that person was also named in Wave 2:

  0 = not mentioned in Wave 2
  1 = mentioned first in Wave 2
  2 = mentioned second in Wave 2
  3 = mentioned third in Wave 2


SOFTWARE REQUIREMENTS
---------------------------------------------------------------------
Stata (for brazilnet_shaping.do)
  - Requires the user-written command copydesc:  ssc install copydesc

R (version 4.x recommended)
  - Scripts using pacman::p_load() install missing packages
    automatically. The packages used across the R scripts are:

    arm, broom, conflicted, cowplot, dotwhisker, dplyr, ggplot2,
    ggpubr, ggrepel, ggsci, gmodels, gridGraphics, haven, Hmisc,
    lubridate, marginaleffects, mediation, nnet, patchwork,
    performance, psych, purrr, readr, sensemakr, stargazer, texreg,
    tidyverse, xtable


HOW TO RUN
---------------------------------------------------------------------
Set the working directory to this folder in both Stata and R, then
run the scripts in this order:

  1. brazilnet_shaping.do
       Reads:   TwoCityPanelStudy.dta, brazil_discussant_retention.dta
       Creates: brazil_net_wide.dta, brazilnet_data_v2.csv

  2. candidate_switching.R
       Reads:   brazilnet_data_v2.csv
       Creates: analysis_dat.Rds
       Output:  main candidate-switching models and predicted-
                probability figure; appendix sensitivity analyses

  3. descriptives.R
       Reads:   analysis_dat.Rds
       Output:  appendix summary statistics tables

  4. multinomial_and_mediation.R
       Reads:   analysis_dat.Rds
       Output:  multinomial vote-choice models and figure; mediation
                analysis and appendix mediation figures

  5. performance_evals.R
       Reads:   analysis_dat.Rds
       Output:  performance-evaluation models, figure, and appendix
                table

  6. plot_support_lula.R
       Reads:   TwoCityPanelStudy.dta
       Output:  appendix figure of support for Lula over time

  7. robustness.R
       Reads:   analysis_dat.Rds
       Output:  appendix robustness checks (alternative measures,
                interactions, added controls, disaggregated and
                lagged-attitude mediation)

The intermediate files (brazil_net_wide.dta, brazilnet_data_v2.csv,
analysis_dat.Rds) are created by scripts 1 and 2 and are not
included in the package. Figures are written to figs/ and tables to
tables/.

Note: the original scripts were run from the author's working
directory; the Stata script's absolute path has been removed, so set
your working directory to this folder before running.


QUESTIONS
---------------------------------------------------------------------
Please contact the corresponding author with any questions about
reproducing these results.
