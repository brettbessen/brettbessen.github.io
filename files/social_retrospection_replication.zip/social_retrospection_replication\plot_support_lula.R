
# Setup -----------------------------

if (!require("pacman")) install.packages("pacman")

pacman::p_load(haven, tidyverse, ggplot2, gmodels, ggpubr, ggrepel, stargazer, performance, marginaleffects, ggsci, nnet, dotwhisker, broom, mediation, conflicted, arm, psych, texreg,
               sensemakr, gridGraphics)

conflicts_prefer(dplyr::select)
conflicts_prefer(dplyr::filter)
conflicts_prefer(mediation::mediate)


# Plot Support for Lula --------------------

## Load the original data:

# original two city data
twocity <- read_dta("TwoCityPanelStudy.dta")

# code to reshape wide

# # reshape long to wide 
# twocity_wide <- pivot_wider(twocity,
#                             names_prefix = "pros_vote_w",
#                             id_cols = c(id, date),
#                             names_from = wave,
#                             values_from = v22c_presvote)

#Shape data for plotting:

# vars we want to plot 
lula_dat <- twocity |> 
  select(id, wave, date, v22c_presvote)

# recode vote for lula 
lula_dat <-  lula_dat |> 
  mutate(lula = case_match(v22c_presvote,
                           2 ~ 1, # lula
                           1 ~ 0, # Ciro 
                           3:17 ~ 0)) # Other non-missings



#Functions for mean and Confidence Intervals
lower <- function(var) { ci.binom(na.omit(var))[2] }
upper <- function(var) { ci.binom(na.omit(var))[3] }
est <- function(var) { ci.binom(na.omit(var))[1] } 


# make dataframe for plotting:

# proportion vote for lula
lula_dat <- lula_dat |> 
  group_by(wave) |> 
  summarise(lower = lower(lula),
            upper = upper(lula),
            est = est(lula))

# manually add the dates:
# wave number: March/April 2002=1, August 2002=2, October 2002=3,
# May 2004=4, July 2006=5 October 2006=6.
wave_dates <- data.frame(
  wave = 1:6,
  date = as.Date(c("2002-04-01", "2002-08-1", "2002-10-01", 
                   "2004-5-01", "2006-7-01", "2006-10-01")),
  label = c(NA, NA, "Wave 3", NA, "Wave 5", NA)
)

# join together
lula_dat <- left_join(lula_dat, wave_dates)


# separate dataframe to label key events
events <- data.frame(
  event = c("Lula Elected", "Pension Reform", "Mensalão scandal"),
  date = as.Date(c("2002-10-27", "2003-12-12", "2005-06-06"))
)


# make sure plot appears in english
Sys.setlocale("LC_ALL", "English")

# plot
ggplot() +
  geom_pointrange(data = lula_dat, aes(x = date, y = est, ymin = lower, ymax = upper)) +
  geom_line(data = lula_dat, aes(x = date, y = est), alpha = .5, linetype = 2) +
  geom_text(data = events, aes(x = date, y = .23, label = event), size = 3.5) +
  geom_segment(data = events, aes(x = date, y = .22, xend = date, yend = .21)) +
  scale_x_date(date_labels = "%b %y", date_breaks = "3 month") +
  labs(x = "", y = "Prop. Supporting Lula", title = "Support for Lula in a Snap Election") +
  scale_y_continuous(limits = c(.21,.55), breaks = seq(.25, .55, .05)) +
  theme_pubr() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) 


ggsave("figs/support_lula_2.pdf", height = 4, width = 6)
