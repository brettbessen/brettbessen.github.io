# Multinomial Models and Mediaton Analysis
## Estimates Models in "Patterns of Candidate Switching"
## Performs Mediation Analysis in "Performance Evaluations as a Mediator 

# Setup -----------------------------

if (!require("pacman")) install.packages("pacman")

pacman::p_load(haven, tidyverse, ggplot2, gmodels, ggpubr,
               ggrepel, stargazer, performance, marginaleffects, 
               ggsci, nnet, dotwhisker, broom, mediation, conflicted, 
               arm, psych, texreg, cowplot,
               sensemakr, gridGraphics, patchwork, readr)

conflicts_prefer(dplyr::select)
conflicts_prefer(dplyr::filter)
conflicts_prefer(mediation::mediate)

dat <- read_rds("analysis_dat.Rds")

# Multinomial Models ---------------------------------------


# Label Vote Choice 
dat <- dat |> 
  mutate(vote_w5 = case_match(v22c_presvote5, 
                              1 ~ "Ciro",
                              2 ~ "Lula (PT)" ,
                              10 ~ "Alckmin (PSDB)",
                              12 ~ "Helena (PSOL)",
                              #17 ~ "No One",
                              c(9, 11, 13, 14, 16) ~ "Other"),
         
         vote_w6 = case_match(v22c_presvote6, 
                              1 ~ "Ciro",
                              2 ~ "Lula (PT)" ,
                              10 ~ "Alckmin (PSDB)",
                              12 ~ "Helena (PSOL)",
                              #17 ~ "No One",
                              c(9, 11, 13, 14, 16) ~ "Other")
         
  )


dat$vote_w5 <- factor(dat$vote_w5)
dat$vote_w5 <- relevel(dat$vote_w5, ref = "Lula (PT)")


my_colors <-  c("Lula (PT)" = "darkred", 
                "Alckmin (PSDB)" = "darkblue",
                "Helena (PSOL)" ="darkorange",
                "Other" = "darkgreen")
#"No One" = "gray20" 

my_lines <- c("Lula (PT)" = "solid", 
              "Helena (PSOL)" = "dashed", 
              "Other" = "dotdash", 
              "Alckmin (PSDB)" = "dotted")


## Lula Voters ------------------------------

# Model 2 -- Lula Voters
lula_mlm_mod <- multinom(vote_w5 ~ prop_disagree_w5a + prop_disagree_w3a + n_discuss_w5 +
                           n_discuss_w3 +  het_w5 + het_w3 + net_volatility + pid_yes_w5 + pid_yes_w3 +
                           lula_eval_w5 + factor(city5) + media_w3 + knowledge_w3, 
                         family = binomial(link = "logit"), data = subset(dat, vote_lula == "Lula"))

# get predictions
mlm_lula <- predictions(lula_mlm_mod, newdata = datagrid(
  prop_disagree_w5a  = seq(0, 1, .1),
  pid_yes_w3 = c(0,1), 
  pid_yes_w5 = c(0,1)))

# subset for labeling
# mlm_lula_labs <- mlm_lula |> 
#   filter(prop_disagree_w5a == 1 & pid_yes_w3 == 1 & pid_yes_w5 == 1)


lula_partisans <- mlm_lula |> 
  filter(pid_yes_w3 == 1 & pid_yes_w5 == 1) |> 
  ggplot(aes(x = prop_disagree_w5a, y = estimate, color = group, 
                                  linetype = group, shape = group)) +
  geom_line() +
  labs(x = NULL, y = NULL,
       color = "Candidate Support", title = "A. Partisan \nLula Voters (2002)") +
  #geom_text_repel(data = mlm_lula_labs, aes(label=group, colour=group)) +
  geom_point() +
  scale_x_continuous(limits = c(0,1.10), breaks = seq(0, 1, .25)) +
  scale_y_continuous(limits = c(0,1), breaks = seq(0, 1, .25)) +
  scale_linetype_manual(values = my_lines) +
  scale_color_manual(values = my_colors) +
  theme_classic() +
  theme(legend.position = "bottom", 
        plot.title = element_text(hjust = 0.5, size = 11))  +
  guides(
    color = guide_legend("Candidate Support"),
    linetype = guide_legend("Candidate Support"),
    shape = guide_legend("Candidate Support")
  )

lula_partisans

# subset for labeling
# mlm_lula_labs <- mlm_lula |> 
#   filter(prop_disagree_w5a == 1 & pid_yes_w3 == 0 & pid_yes_w5 == 0)

lula_non_partisans <- mlm_lula |> 
  filter(pid_yes_w3 == 0 & pid_yes_w5 == 0) |> 
  ggplot(aes(x = prop_disagree_w5a, y = estimate, color = group, 
             linetype = group, shape = group)) +
  geom_line() +
  geom_point() +
  labs(x = NULL, y = NULL,
       color = "Candidate Support", title = "B. Non-Partisan \nLula Voters (2002)") +
  #geom_text_repel(data = mlm_lula_labs, aes(label=group, colour=group)) +
  scale_x_continuous(limits = c(0,1.10), breaks = seq(0, 1, .25)) +
  scale_y_continuous(limits = c(0,1), breaks = seq(0, 1, .25)) +
  scale_linetype_manual(values = my_lines) +
  scale_color_manual(values = my_colors) +
  theme_classic() +
  theme(legend.position = "bottom", 
        plot.title = element_text(hjust = 0.5, size = 11)) +
  guides(
    color = guide_legend("Candidate Support"),
    linetype = guide_legend("Candidate Support"),
    shape = guide_legend("Candidate Support")
  )

lula_non_partisans

## Other Voters -----------------------------------------

# Model 2 -- Others
others_mlm_mod <- multinom(vote_w5 ~ prop_disagree_w5a + prop_disagree_w3a + n_discuss_w5 +
                             n_discuss_w3 +  het_w5 + het_w3 + net_volatility + pid_yes_w5 + pid_yes_w3 +
                             lula_eval_w5 + factor(city5) + media_w3 + knowledge_w3, 
                           family = binomial(link = "logit"), data = subset(dat, vote_lula == "Other"))

# predictions
mlm_others_preds <- predictions(others_mlm_mod, newdata = datagrid(
  prop_disagree_w5a  = seq(0, 1, .1),
  pid_yes_w3 = 0,
  pid_yes_w5 = 0))

# subset for labeling
# mlm_other_labs <- mlm_others_preds |> 
#   filter(prop_disagree_w5a == 1)

# plot others
other_voters <- mlm_others_preds |> 
  ggplot(aes(x = prop_disagree_w5a, 
             y = estimate, color = group, linetype = group,
             shape = group)) +
  geom_line() +
  geom_point() +
  labs(y =  NULL, x = "Proportion Disagreement (2006)",
       color = "Candidate Support", title = "C. Opposition Voters (2002)") +
  #geom_text_repel(data = mlm_other_labs, aes(label=group, colour=group)) +
  scale_x_continuous(limits = c(0,1.10), breaks = seq(0, 1, .25)) +
  scale_y_continuous(limits = c(0,1), breaks = seq(0, 1, .25)) +
  scale_linetype_manual(values = my_lines) +
  scale_color_manual(values = my_colors) +
  theme_classic() +
  theme(legend.position = "bottom", 
        plot.title = element_text(hjust = 0.5, size = 11),
        axis.title.x = element_text(size = 13, face = "bold")) +
  guides(
    color = guide_legend("Candidate Support", nrow = 2),
    linetype = guide_legend("Candidate Support", nrow = 2),
    shape = guide_legend("Candidate Support", nrow = 2)
  )


other_voters


## Combine Plots  -------------------

my_plots <- ggarrange(
  ggarrange(lula_partisans + rremove("legend"), 
            lula_non_partisans + rremove("legend"), ncol = 2),
  other_voters,
  nrow = 2,
  common.legend = TRUE,
  legend = "bottom"
) 

# Add Common Y-Title  
my_plots <- annotate_figure(
  my_plots,
  left = text_grob("Probability of Support (2006)",
                   rot = 90, size = 13, face = "bold", vjust = 1)
)

my_plots
 

# ggsave("figs/mlm_preds.pdf", width = 6, height = 6)
ggsave("figs/mlm_preds.tif", width = 6, height = 6, dpi = 300)



## Out to Latex ----------------------------


stargazer(lula_mlm_mod, type = "text")

stargazer_labs <- c(
  "Prop. Disagreeing$_{t}$",
  "Prop. Disagreeing$_{t-1}$",
  "Num. Disscussants$_{t}$",
  "Num. Disscussants$_{t-1}$",
  "Network Diversity$_{t}$",
  "Network Diversity$_{t-1}$",
  "Network Change",
  "Party Identity$_{t}$",
  "Party Identity$_{t-1}$",
  "Performance Evaluation$_{t}$",
  "Media Consumption$_{t-1}$",
  "Political Knowledge$_{t-1}$"
)

# Lula Voters
stargazer(lula_mlm_mod, 
          type = "latex",
          omit = "city5",
          digits = 2,
          header = F,
          dep.var.labels.include = T,
          model.numbers = F,
          no.space = T,
          star.cutoffs = c(0.05, 0.01, 0.001),
          covariate.labels = stargazer_labs)


# Lula Voters
stargazer(others_mlm_mod, 
          type = "latex",
          omit = "city5",
          digits = 2,
          header = F,
          dep.var.labels.include = T,
          model.numbers = F,
          no.space = T,
          star.cutoffs = c(0.05, 0.01, 0.001),
          covariate.labels = stargazer_labs)


# Mediation -------------------------


# Select Variables We'll Use
med_df <- dat |> 
  dplyr::select(switch1, prop_disagree_w5a, prop_disagree_w3a, n_discuss_w5,
         n_discuss_w3, het_w5, het_w3, net_volatility,
         pid_yes_w3,pid_yes_w5, lula_eval_w5, media_w3, knowledge_w3,
         city5, vote_lula) |> 
  na.omit()


# Disagree to Lula Eval
eval_fit <- lm(lula_eval_w5 ~ prop_disagree_w5a + prop_disagree_w3a + n_discuss_w5 + 
                 n_discuss_w3 + het_w5 + het_w3 + net_volatility + pid_yes_w3 + pid_yes_w5 +
                 media_w3 + knowledge_w3 + factor(city5), data = subset(med_df, vote_lula == "Lula"))


eval_preds <- predictions(eval_fit, newdata = datagrid(prop_disagree_w5a = c(0,  .33))) |> 
  dplyr::select(estimate, prop_disagree_w5a)

eval_preds$estimate[1] 

eval_preds$estimate[2] 

# Model of Switching  (LPM)
switch_fit_lm <- lm(switch1 ~ lula_eval_w5 + prop_disagree_w5a + prop_disagree_w3a + n_discuss_w5 +
                      n_discuss_w3 + het_w5 + het_w3 +  net_volatility + pid_yes_w3 + pid_yes_w5 + 
                      media_w3 + knowledge_w3 + factor(city5), data = subset(med_df, vote_lula == "Lula")) 
#family = binomial(link = "logit"))

switch_preds <- predictions(switch_fit_lm, newdata = datagrid(lula_eval_w5 = c(6.21,  5.81))) |> 
  dplyr::select(estimate, lula_eval_w5)




# Model of Switching (Probit)
switch_fit_prob <- glm(switch1 ~ lula_eval_w5 + prop_disagree_w5a + prop_disagree_w3a + n_discuss_w5 +
                         n_discuss_w3 + het_w5 + het_w3 +  net_volatility + pid_yes_w3 + pid_yes_w5 + 
                         media_w3 + knowledge_w3 + factor(city5), data = subset(med_df, vote_lula == "Lula"), 
                       family = binomial(link = "probit"))


med_lm <- mediation::mediate(model.m = eval_fit, 
                  model.y = switch_fit_lm,
                  treat = "prop_disagree_w5a",
                  mediator = "lula_eval_w5",
                  control.value = 0, 
                  treat.value = .33)


med_prob <- mediation::mediate(model.m = eval_fit, 
                    model.y = switch_fit_prob,
                    treat = "prop_disagree_w5a",
                    mediator = "lula_eval_w5",
                    control.value = 0, 
                    treat.value = .33)


## Results to Latex ------------------------------------------

coef_list <- list(
  "prop_disagree_w5a" = "Prop. Disagreeing$_{t}$",
  "prop_disagree_w3a" = "Prop. Disagreeing$_{t-1}$",
  "lula_eval_w5" = "Performance Evaluation$_{t}$",
  "n_discuss_w5"  = "Num. Disscussants$_{t}$",
  "n_discuss_w3" = "Num. Disscussants$_{t-1}$",
  "het_w5"  =  "Network Diversity$_{t}$",
  "het_w3" =  "Network Diversity$_{t-1}$", 
  "net_volatility" = "Network Change",
  "pid_yes_w51" = "Party Identity$_{t}$", 
  "pid_yes_w31" = "Party Identity$_{t-1}$", 
  "media_w3" = "Media Consumption$_{t-1}$",
  "knowledge_w3" = "Political Knowledge$_{t-1}$",
  "(Intercept)" = "Intercept"
)


texreg(list("Peformance Eval" = eval_fit, 
            "Switched from Lula" = switch_fit_lm, 
            "Switched from Lula" = switch_fit_prob),
       caption = "Models used in Mediation Analysis",
       label = "si_med_fits",
       custom.coef.map = coef_list, 
       include.bic = F,
       include.deviance = F)


## Plot Mediation Results -------------------

# Probit Results
summary(med_prob)
pdf("figs/mediation_probit.pdf", height = 4, width = 4)
plot(med_prob)
mtext("ACME = .023, [0.005, .04] \n Prop Mediated = 0.10, [0.02, 0.19]",  
      side = 1, line = 4)

dev.off()


summary(medsens(med_prob))
plot(medsens(med_prob))
dev.off()


# LM Results
summary(med_lm)
pdf("figs/mediation_lm.pdf", height = 4, width = 4)
plot(med_lm)
mtext("ACME = .022, [0.004, .04] \n Prop Mediated = 0.09, [0.02, 0.17]",  
      side = 1, line = 4)
dev.off()

summary(medsens(med_lm))
pdf("figs/mediation_lm_sens.pdf", height = 4, width = 4)
plot(medsens(med_lm))
dev.off()



