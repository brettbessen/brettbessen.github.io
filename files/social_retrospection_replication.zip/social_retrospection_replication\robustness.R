# Robustness Checks
# Addresses reviewer-requested robustness analyses (JEPOP Round 1)
#
# CHECK 1: Disaggregated mediation (economic, corruption, crime mediators)
# CHECK 2: Alternative disagreement measure (excluding unknown-pref alters)
# CHECK 3: Network size x disagreement interaction
# CHECK 4: Alternative network volatility measure (prop. new W5 discussants; switching + eval outcomes)
# CHECK 5: Personality / social behavior robustness
# CHECK 6: Mediation with lagged attitude toward Lula (Wave 3; adds v41a_thermlula3)
#
# Run after candidate_switching.R (which creates analysis_dat.Rds)

# Setup ----------------------------------------------------------------

if (!require("pacman")) install.packages("pacman")
pacman::p_load(tidyverse, mediation, marginaleffects, performance, texreg,
               xtable, ggpubr, patchwork, dotwhisker, conflicted)

conflicts_prefer(dplyr::select)
conflicts_prefer(dplyr::filter)
conflicts_prefer(mediation::mediate)

dat <- read_rds("analysis_dat.Rds")

# Helper: insert minipage note between \end{tabular} and \end{table} --
add_minipage_note <- function(file, note) {
  latex <- paste(readLines(file), collapse = "\n")
  minipage <- paste0(
    "\\begin{minipage}{.80\\textwidth}\n",
    "  \\singlespacing \\small\n",
    "  \\textbf{Note:} ", note, "\n",
    "\\end{minipage}"
  )
  latex <- sub("\\end{table}", paste0(minipage, "\n\\end{table}"), latex, fixed = TRUE)
  writeLines(latex, file)
}


# Model 3 specification (mirrors candidate_switching.R) ---------------#

m1_vars <- c("prop_disagree_w5a", "prop_disagree_w3a", "city5")

m2_vars <- union(m1_vars, c("n_discuss_w5", "n_discuss_w3", "het_w5", "het_w3",
                             "net_volatility", "pid_yes_w5", "pid_yes_w3",
                             "lula_eval_w5"))

m3_vars <- union(m2_vars, c("media_w3", "knowledge_w3"))

# Shared coefficient labels for tables
coef_list <- list(
  "prop_disagree_w5a"  = "Prop. Disagreeing$_{t}$",
  "prop_disagree_w3a"  = "Prop. Disagreeing$_{t-1}$",
  "lula_eval_w5"       = "Performance Evaluation$_{t}$",
  "n_discuss_w5"       = "Num. Discussants$_{t}$",
  "n_discuss_w3"       = "Num. Discussants$_{t-1}$",
  "het_w5"             = "Network Diversity$_{t}$",
  "het_w3"             = "Network Diversity$_{t-1}$",
  "net_volatility"     = "Network Change",
  "pid_yes_w51"        = "Party Identity$_{t}$",
  "pid_yes_w31"        = "Party Identity$_{t-1}$",
  "media_w3"           = "Media Consumption$_{t-1}$",
  "knowledge_w3"       = "Political Knowledge$_{t-1}$",
  "(Intercept)"        = "Intercept"
)

# ======================================================================#
# CHECK 1: Disaggregated Mediation Analysis ----------------------------
#
# Re-runs mediation using four separate mediators instead of the
# composite lula_eval_w5 index:
#   - Jobs:       jobs_therm_w5
#   - Inflation:  inflation_therm_w5
#   - Corruption: corrupt_therm_w5
#   - Crime:      crime_therm_w5
#
# Lula voters only; 0.33 point increase in disagreement (= adding
# one disagreeing partner to a 3-person network).
# Stage 1: OLS (continuous mediators)
# Stage 2: Probit (binary switching outcome)
# ======================================================================#

# Analysis sample: Lula voters, complete cases on all M3 vars + mediators
med1_df <- dat |>
  dplyr::select(switch1, prop_disagree_w5a, prop_disagree_w3a,
                n_discuss_w5, n_discuss_w3, het_w5, het_w3,
                net_volatility, pid_yes_w3, pid_yes_w5,
                media_w3, knowledge_w3, city5, vote_lula,
                jobs_therm_w5, inflation_therm_w5,
                corrupt_therm_w5, crime_therm_w5) |>
  na.omit() |>
  filter(vote_lula == "Lula")

# Check 1 sample N = nrow(med1_df)

# Stage 1 RHS: M3 controls, excluding lula_eval (replaced by each mediator)
s1_rhs <- paste(
  c("prop_disagree_w5a", "prop_disagree_w3a", "n_discuss_w5", "n_discuss_w3",
    "het_w5", "het_w3", "net_volatility", "pid_yes_w3", "pid_yes_w5",
    "media_w3", "knowledge_w3", "factor(city5)"),
  collapse = " + "
)

# Stage 1 models (OLS: disagreement -> mediator)
jobs_s1      <- lm(as.formula(paste("jobs_therm_w5 ~",      s1_rhs)), data = med1_df)
inflation_s1 <- lm(as.formula(paste("inflation_therm_w5 ~", s1_rhs)), data = med1_df)
corrupt_s1   <- lm(as.formula(paste("corrupt_therm_w5 ~",   s1_rhs)), data = med1_df)
crime_s1     <- lm(as.formula(paste("crime_therm_w5 ~",     s1_rhs)), data = med1_df)

# Stage 2 RHS: M3 controls + mediator
s2_controls <- paste(
  c("prop_disagree_w5a", "prop_disagree_w3a", "n_discuss_w5", "n_discuss_w3",
    "het_w5", "het_w3", "net_volatility", "pid_yes_w3", "pid_yes_w5",
    "media_w3", "knowledge_w3", "factor(city5)"),
  collapse = " + "
)

# Stage 2 models (Probit: disagreement + mediator -> switching)
jobs_s2      <- glm(as.formula(paste("switch1 ~ jobs_therm_w5 +",      s2_controls)),
                    family = binomial("probit"), data = med1_df)
inflation_s2 <- glm(as.formula(paste("switch1 ~ inflation_therm_w5 +", s2_controls)),
                    family = binomial("probit"), data = med1_df)
corrupt_s2   <- glm(as.formula(paste("switch1 ~ corrupt_therm_w5 +",   s2_controls)),
                    family = binomial("probit"), data = med1_df)
crime_s2     <- glm(as.formula(paste("switch1 ~ crime_therm_w5 +",     s2_controls)),
                    family = binomial("probit"), data = med1_df)

# Mediation (treatment = 0.33 increase, consistent with main analysis)
med_jobs <- mediation::mediate(
  model.m = jobs_s1,      model.y = jobs_s2,
  treat = "prop_disagree_w5a", mediator = "jobs_therm_w5",
  control.value = 0, treat.value = 0.33
)
med_inflation <- mediation::mediate(
  model.m = inflation_s1, model.y = inflation_s2,
  treat = "prop_disagree_w5a", mediator = "inflation_therm_w5",
  control.value = 0, treat.value = 0.33
)
med_corrupt <- mediation::mediate(
  model.m = corrupt_s1,   model.y = corrupt_s2,
  treat = "prop_disagree_w5a", mediator = "corrupt_therm_w5",
  control.value = 0, treat.value = 0.33
)
med_crime <- mediation::mediate(
  model.m = crime_s1,     model.y = crime_s2,
  treat = "prop_disagree_w5a", mediator = "crime_therm_w5",
  control.value = 0, treat.value = 0.33
)

summary(med_jobs)
summary(med_inflation)
summary(med_corrupt)
summary(med_crime)


# --- Tables: economic mediators / non-economic mediators --------------#

med_coef_list <- list(
  "prop_disagree_w5a"  = "Prop. Disagreeing$_{t}$",
  "prop_disagree_w3a"  = "Prop. Disagreeing$_{t-1}$",
  "jobs_therm_w5"      = "Jobs Eval.$_{t}$",
  "inflation_therm_w5" = "Inflation Eval.$_{t}$",
  "corrupt_therm_w5"   = "Corruption Eval.$_{t}$",
  "crime_therm_w5"     = "Crime Eval.$_{t}$",
  "n_discuss_w5"       = "Num. Discussants$_{t}$",
  "n_discuss_w3"       = "Num. Discussants$_{t-1}$",
  "het_w5"             = "Network Diversity$_{t}$",
  "het_w3"             = "Network Diversity$_{t-1}$",
  "net_volatility"     = "Network Change",
  "pid_yes_w51"        = "Party Identity$_{t}$",
  "pid_yes_w31"        = "Party Identity$_{t-1}$",
  "media_w3"           = "Media Consumption$_{t-1}$",
  "knowledge_w3"       = "Political Knowledge$_{t-1}$",
  "(Intercept)"        = "Intercept"
)

med_note <- "Sample restricted to respondents who voted for Lula in Wave 3 (2002). M1 predicts the mediator via OLS. M2 (``Switched'') is a probit model of switching away from Lula."

texreg(
  list("Jobs (M1)"      = jobs_s1,      "Switched (M2)" = jobs_s2,
       "Inflation (M1)" = inflation_s1, "Switched (M2)" = inflation_s2),
  caption         = "Disaggregated Mediation: Economic Mediators (Lula Voters).",
  caption.above   = TRUE,
  label           = "tab:med_economic",
  custom.coef.map = med_coef_list,
  include.bic     = FALSE,
  include.deviance = FALSE,
  dcolumn         = FALSE,
  file            = "tables/table_med_economic.tex"
)
add_minipage_note("tables/table_med_economic.tex", med_note)
# Saved: tables/table_med_economic.tex

texreg(
  list("Corruption (M1)" = corrupt_s1, "Switched (M2)" = corrupt_s2,
       "Crime (M1)"      = crime_s1,   "Switched (M2)" = crime_s2),
  caption         = "Disaggregated Mediation: Non-Economic Mediators (Lula Voters).",
  caption.above   = TRUE,
  label           = "tab:med_noneconomic",
  custom.coef.map = med_coef_list,
  include.bic     = FALSE,
  include.deviance = FALSE,
  dcolumn         = FALSE,
  file            = "tables/table_med_noneconomic.tex"
)
add_minipage_note("tables/table_med_noneconomic.tex", med_note)
# Saved: tables/table_med_noneconomic.tex


acme_text <- function(med_obj) {
  sprintf("ACME = %.3f [%.3f, %.3f], p = %.3f",
          med_obj$d.avg, med_obj$d.avg.ci[1], med_obj$d.avg.ci[2], med_obj$d.avg.p)
}

pdf("figs/fig_disagg_mediation.pdf", height = 8, width = 8)
par(mfrow = c(2, 2), mar = c(6, 4, 4, 2))
plot(med_jobs);      title("Jobs Evaluation");      mtext(acme_text(med_jobs),      side = 1, line = 4.5, cex = 0.75)
plot(med_inflation); title("Inflation Evaluation"); mtext(acme_text(med_inflation), side = 1, line = 4.5, cex = 0.75)
plot(med_crime);     title("Crime Evaluation");     mtext(acme_text(med_crime),     side = 1, line = 4.5, cex = 0.75)
plot(med_corrupt);   title("Corruption Evaluation");mtext(acme_text(med_corrupt),   side = 1, line = 4.5, cex = 0.75)
dev.off()
# Saved: figs/fig_disagg_mediation.pdf


# ===================================================================================#
# CHECK 2: Alternative Disagreement Measure — Exclude Unknown-Pref Alters -----------
#
# CODING 
# v7*c_disc1presvote*
# 17 - No-one, 18 - No Sé, 19 - No response, 99 - Missing 
#
# ALTERNATIVE measure: constructed directly from the raw discussant vote
# variables (v74c_disc{i}presvote{w}). Alters with DK codes or no named
# discussant (NA) are excluded from both numerator and denominator.
# Cases where all discussants have unknown preferences are coded NA.
# ===================================================================================#


# "Don't know" / non-stated codes in the raw discussant vote variables
dk_codes <- c(17L, 18L, 19L, 99L)

## Wave 5 alternative measure ------------------------------------------- #
# Raw vars: v74c_disc1presvote5 ... v77c_disc4presvote5
# Respondent's own wave-5 vote: pres_vote_w5


dat <- dat |>
  mutate(

    # -- Step 1: Per-discussant disagreement indicators (.d1_w5 -- .d4_w5) ----#
    # Each temp variable is:
    #   NA  — slot is empty OR discussant's preference is unknown (dk_codes)
    #   0   — discussant voted the same as the respondent (agrees)
    #   1   — discussant voted differently from the respondent (disagrees)
    # These are dropped via select() at the end and never appear in the final data.

    .d1_w5 = case_when(
      is.na(v74c_disc1presvote5) | v74c_disc1presvote5 %in% dk_codes ~ NA_integer_,
      TRUE ~ as.integer(v74c_disc1presvote5 != pres_vote_w5)
    ),
    .d2_w5 = case_when(
      is.na(v75c_disc2presvote5) | v75c_disc2presvote5 %in% dk_codes ~ NA_integer_,
      TRUE ~ as.integer(v75c_disc2presvote5 != pres_vote_w5)
    ),
    .d3_w5 = case_when(
      is.na(v76c_disc3presvote5) | v76c_disc3presvote5 %in% dk_codes ~ NA_integer_,
      TRUE ~ as.integer(v76c_disc3presvote5 != pres_vote_w5)
    ),
    .d4_w5 = case_when(
      is.na(v77c_disc4presvote5) | v77c_disc4presvote5 %in% dk_codes ~ NA_integer_,
      TRUE ~ as.integer(v77c_disc4presvote5 != pres_vote_w5)
    ),

    # -- Step 2: Count discussants with a stated (non-missing) preference ------#
    # Denominator for the alternative measure; excludes unknown-pref alters.
    n_stated_w5 = rowSums(!is.na(cbind(.d1_w5, .d2_w5, .d3_w5, .d4_w5))),

    # -- Step 3: Proportion of stated-preference alters who disagree -----------#
    #   0    — respondent named no discussants (empty network)
    #   NA   — network exists but all alter preferences are unknown
    #   else — share of known-preference alters who disagree
    prop_disagree_alt_w5 = case_when(
      n_discuss_w5 == 0 ~ 0,
      n_stated_w5  == 0 ~ NA_real_,
      TRUE ~ rowSums(cbind(.d1_w5, .d2_w5, .d3_w5, .d4_w5), na.rm = TRUE) / n_stated_w5
    )

  ) |>
  select(-.d1_w5, -.d2_w5, -.d3_w5, -.d4_w5)

# Check the work
dat |> 
  filter(!is.na(pres_vote_w5)) |> 
  select(v74c_disc1presvote5,
         v75c_disc2presvote5,
         v76c_disc3presvote5,
         v77c_disc4presvote5,
         n_discuss_w5,
         n_stated_w5,
         prop_disagree_alt_w5,
         prop_disagree_w5a, 
         pres_vote_w5) 
         

## Wave 3 alternative measure -------------------------------------------#
# Raw vars: v74c_disc1presvote3 ... v77c_disc4presvote3
# Respondent's own wave-3 vote: pres_vote_w3

dat <- dat |>
  mutate(

    # -- Step 1: Per-discussant disagreement indicators (.d1_w3 -- .d4_w3) ----#
    # Each temp variable is:
    #   NA  — slot is empty OR discussant's preference is unknown (dk_codes)
    #   0   — discussant voted the same as the respondent (agrees)
    #   1   — discussant voted differently from the respondent (disagrees)
    # These are dropped via select() at the end and never appear in the final data.

    .d1_w3 = case_when(
      is.na(v74c_disc1presvote3) | v74c_disc1presvote3 %in% dk_codes ~ NA_integer_,
      TRUE ~ as.integer(v74c_disc1presvote3 != pres_vote_w3)
    ),
    .d2_w3 = case_when(
      is.na(v75c_disc2presvote3) | v75c_disc2presvote3 %in% dk_codes ~ NA_integer_,
      TRUE ~ as.integer(v75c_disc2presvote3 != pres_vote_w3)
    ),
    .d3_w3 = case_when(
      is.na(v76c_disc3presvote3) | v76c_disc3presvote3 %in% dk_codes ~ NA_integer_,
      TRUE ~ as.integer(v76c_disc3presvote3 != pres_vote_w3)
    ),
    .d4_w3 = case_when(
      is.na(v77c_disc4presvote3) | v77c_disc4presvote3 %in% dk_codes ~ NA_integer_,
      TRUE ~ as.integer(v77c_disc4presvote3 != pres_vote_w3)
    ),

    # -- Step 2: Count discussants with a stated (non-missing) preference ------#
    # Denominator for the alternative measure; excludes unknown-pref alters.
    n_stated_w3 = rowSums(!is.na(cbind(.d1_w3, .d2_w3, .d3_w3, .d4_w3))),

    # -- Step 3: Proportion of stated-preference alters who disagree -----------#
    #   0    — respondent named no discussants (empty network)
    #   NA   — network exists but all alter preferences are unknown
    #   else — share of known-preference alters who disagree
    prop_disagree_alt_w3 = case_when(
      n_discuss_w3 == 0 ~ 0,
      n_stated_w3  == 0 ~ NA_real_,
      TRUE ~ rowSums(cbind(.d1_w3, .d2_w3, .d3_w3, .d4_w3), na.rm = TRUE) / n_stated_w3
    )

  ) |>
  select(-.d1_w3, -.d2_w3, -.d3_w3, -.d4_w3)


# --- Summary comparison of measures ----------------------------------#
# Restricted to the Model 1 analytic sample: non-missing on switch1 and
# both disagreement measures (main and alternative) for each wave.
# Rows = waves; columns = mean of each key variable.

sum_dat <- dat |>
  filter(!is.na(switch1))

compare_tbl <- tibble(
  Wave                    = c("Wave 5 (t)", "Wave 3 (t-1)"),
  `N Discuss`             = c(mean(sum_dat$n_discuss_w5,          na.rm = TRUE),
                               mean(sum_dat$n_discuss_w3,          na.rm = TRUE)),
  `N Stated`              = c(mean(sum_dat$n_stated_w5,            na.rm = TRUE),
                               mean(sum_dat$n_stated_w3,            na.rm = TRUE)),
  `Prop. Disagree (Main)` = c(mean(sum_dat$prop_disagree_w5a,     na.rm = TRUE),
                               mean(sum_dat$prop_disagree_w3a,     na.rm = TRUE)),
  `Prop. Disagree (Alt.)` = c(mean(sum_dat$prop_disagree_alt_w5,  na.rm = TRUE),
                               mean(sum_dat$prop_disagree_alt_w3,  na.rm = TRUE))
) |>
  mutate(across(where(is.numeric), ~round(., 3)))

print(compare_tbl)

print(
  xtable(compare_tbl,
         caption = "Comparison of Main and Alternative Disagreement Measures.",
         label   = "tab:alt_compare",
         digits  = c(0, 0, 3, 3, 3, 3)),
  include.rownames  = FALSE,
  booktabs          = TRUE,
  caption.placement = "top",
  file              = "tables/table_alt_measure_compare.tex"
)
add_minipage_note(
  "tables/table_alt_measure_compare.tex",
  paste0("")
)
# Saved: tables/table_alt_measure_compare.tex


# --- M3 RHS: alternative disagreement measure ------------------------#
# Mirrors m3_vars (defined at top of script) but swaps in the
# alternative disagreement variables.

m3_alt <- c("prop_disagree_alt_w5", "prop_disagree_alt_w3", "city5",
            "n_discuss_w5", "n_discuss_w3", "het_w5", "het_w3",
            "net_volatility", "pid_yes_w5", "pid_yes_w3", "lula_eval_w5",
            "media_w3", "knowledge_w3")

# --- M3 split-sample models: main and alternative measure ------------#
# Four models: main/alt x Lula/Other voters.
# Split-sample approach gives clean voter-group-specific coefficients
# for direct comparison in the plot below.

m3_main_lula   <- glm(reformulate(m3_vars, "switch1"), binomial("logit"),
                      data = subset(dat, vote_lula == "Lula"))
m3_main_others <- glm(reformulate(m3_vars, "switch1"), binomial("logit"),
                      data = subset(dat, vote_lula == "Other"))
m3_alt_lula    <- glm(reformulate(m3_alt,  "switch1"), binomial("logit"),
                      data = subset(dat, vote_lula == "Lula"))
m3_alt_others  <- glm(reformulate(m3_alt,  "switch1"), binomial("logit"),
                      data = subset(dat, vote_lula == "Other"))

# Sample sizes
nobs(m3_main_lula); nobs(m3_main_others)
nobs(m3_alt_lula);  nobs(m3_alt_others)

# --- Coefficient plot: disagreement terms, main vs. alternative ------#
# Extracts wave-5 and wave-3 disagreement coefficients from each model,
# labels by measure (Main / Alt.), and facets by voter group.

tidy_disagree <- function(model, voter_group, measure_label) {
  broom::tidy(model, conf.int = TRUE) |>
    filter(str_detect(term, "prop_disagree")) |>
    mutate(
      term        = case_when(
        str_detect(term, "w5") ~ "Disagreement (t)",
        str_detect(term, "w3") ~ "Disagreement (t-1)"
      ),
      model       = measure_label,
      voter_group = voter_group
    )
}

coef_df <- bind_rows(
  tidy_disagree(m3_main_lula,   "Lula Voters",      "Main"),
  tidy_disagree(m3_main_others, "Opposition Voters", "Main"),
  tidy_disagree(m3_alt_lula,    "Lula Voters",      "Excludes DKs"),
  tidy_disagree(m3_alt_others,  "Opposition Voters", "Excludes DKs")
)

fig_alt_coefs <- dwplot(coef_df,
         vline        = geom_vline(xintercept = 0, linetype = "dashed", color = "grey60"),
         dot_args     = list(size = 2.5),
         whisker_args = list(size = 0.7)) +
  facet_wrap(~ voter_group) +
  labs(x     = "Logit Coefficient (95% CI)",
       y     = NULL,
       color = "Disagreement Measure") +
  theme_pubr() +
  theme(legend.position = "bottom",
        strip.text      = element_text(face = "bold"))

fig_alt_coefs

ggsave("figs/fig_alt_coefs.pdf", fig_alt_coefs, height = 4, width = 6)
# Saved: figs/fig_alt_coefs.pdf


# ======================================================================#
# CHECK 3: Network Size x Proportion Disagreeing Interaction ------------
# Source: Reviewer 3, Minor Point 4
#
# A network of 1 (100% disagreeing) and a network of 4 (100%
# disagreeing) represent different levels of exposure. Adds the
# interaction prop_disagree_w5a x n_discuss_w5 to the Model 3
# specification (contemporaneous wave only).
# ======================================================================#

# Model 3 + interaction
m3_int_formula <- as.formula(
  paste("switch1 ~",
        paste(m3_vars, collapse = " + "),
        "+ prop_disagree_w5a:n_discuss_w5")
)

m3_int_lula   <- glm(m3_int_formula, binomial("logit"),
                     data = subset(dat, vote_lula == "Lula"))
m3_int_others <- glm(m3_int_formula, binomial("logit"),
                     data = subset(dat, vote_lula == "Other"))





# --- Plot: predicted switching probability over disagreement ----------#
# x-axis: prop. disagreeing (wave 5), 0-1
# Colored/styled lines: network size (1, 2, or 3 discussants)

make_int_preds <- function(model, voter_label) {
  predictions(
    model,
    newdata = datagrid(
      prop_disagree_w5a = seq(0, 1, .1),
      n_discuss_w5      = 1:3)
    ) |>
    mutate(
      `N Discussants` = factor(n_discuss_w5,
                               levels = 1:3,
                               labels = c("1 Discussant", "2 Discussants", "3 Discussants")),
      voter_group = voter_label
    )
}

preds_lula   <- make_int_preds(m3_int_lula,   "Lula Voters (Oct. 2002)")
preds_others <- make_int_preds(m3_int_others, "Opposition Voters (Oct. 2002)")

plot_int_preds <- function(preds, title_label) {
  ggplot(preds, aes(x = prop_disagree_w5a, y = estimate,
                    color = `N Discussants`, linetype = `N Discussants`,
                    ymin = conf.low, ymax = conf.high)) +
    geom_line(linewidth = 1) +
    geom_ribbon(aes(fill = `N Discussants`), alpha = 0.05, color = NA) +
    scale_x_continuous(breaks = seq(0, 1, .25), labels = scales::percent) +
    scale_y_continuous(limits = c(0, 1)) +
    labs(x = "Proportion Disagreeing (Wave 5)",
         y = "Probability of Switching",
         title = title_label,
         color = NULL, linetype = NULL, fill = NULL) +
    theme_pubr() +
    theme(plot.title      = element_text(hjust = 0.5, size = 11, face = "bold"),
          legend.position = "bottom")
}

fig_int_lula   <- plot_int_preds(preds_lula,   "Lula Voters (Oct. 2002)")
fig_int_others <- plot_int_preds(preds_others, "Opposition Voters (Oct. 2002)")

fig_interaction <- ggarrange(fig_int_lula,
                             fig_int_others + rremove("y.title"),
                             common.legend = TRUE,
                             align         = "v")

fig_interaction

ggsave("figs/fig_network_interaction.pdf", fig_interaction, height = 4, width = 8)
# Saved: figs/fig_network_interaction.pdf


# ======================================================================#
# CHECK 4: Alternative Network Volatility Measure -------------------- 
# Source: Reviewer 3, Minor Point 2                                      #
#                                                                        #
# The main net_volatility measure counts slot-level discussant changes  #
# between waves 3 and 5 and normalizes by 4 (the fixed maximum network  #
# size). Here we test an alternative measure: the proportion of Wave 5  #
# discussants who are entirely new — i.e., not mentioned by the         #
# respondent in Wave 2 (constructed in brazilnet_shaping.do).           #
#                                                                        #
# prop_new_w5 = num. new Wave 5 discussants / total Wave 5 discussants  #
# Set to missing when n_discuss_w5 == 4 (4th slot not tracked in the    #
# retention data). Both outcomes from the main analysis are tested:     #
# candidate switching (logit) and performance evaluations (OLS).        #
# ======================================================================#


# --- Models: Model 3 with prop_new_w5 --------------------------------#
# Swap net_volatility for prop_new_w5 in the full m3 specification.
# Run separately for Lula and Other voter subsamples.

m3_vars_prop_new <- gsub("^net_volatility$", "prop_new_w5", m3_vars)

# Candidate switching (logit)
m4_switch_lula   <- glm(reformulate(m3_vars_prop_new, "switch1"), binomial("logit"),
                         data = subset(dat, vote_lula == "Lula"))
m4_switch_others <- glm(reformulate(m3_vars_prop_new, "switch1"), binomial("logit"),
                         data = subset(dat, vote_lula == "Other"))

m3_vars_prop_new_eval <- setdiff(m3_vars_prop_new, "lula_eval_w5")
# Performance evaluations (OLS)
m4_eval_lula     <- lm(reformulate(m3_vars_prop_new_eval, "lula_eval_w5"),
                        data = subset(dat, vote_lula == "Lula"))
m4_eval_others   <- lm(reformulate(m3_vars_prop_new_eval, "lula_eval_w5"),
                        data = subset(dat, vote_lula == "Other"))

# Sample sizes
nobs(m4_switch_lula); nobs(m4_switch_others)
nobs(m4_eval_lula);   nobs(m4_eval_others)


# --- Equivalent interaction models (full sample) ---------------------#
# All covariates interacted with vote_lula for fit statistics.

m4a_switch_rhs <- paste0("(", paste(m3_vars_prop_new, collapse = " + "), ") * factor(vote_lula)")

m4a_switch_fit <- glm(
  reformulate(m4a_switch_rhs, response = "switch1"),
  family = binomial(link = "logit"),
  data = dat
)

nobs(m4a_switch_fit)
performance_aic(m4a_switch_fit)
performance_pcp(m4a_switch_fit, method = "Gelman-Hill")

m4a_eval_rhs <- paste0("(", paste(m3_vars_prop_new_eval, collapse = " + "), ") * factor(vote_lula)")
m4a_eval_fit <- lm(
  reformulate(m4a_eval_rhs, response = "lula_eval_w5"),
  data = dat
)

nobs(m4a_eval_fit)
performance_aic(m4a_eval_fit)


# --- Regression table ------------------------------------------------#

vol_coef_list <- modifyList(
  coef_list,
  list("prop_new_w5" = "Prop. New Discussants$_{t}$")
)

texreg(
  list(
    "Switch—Lula"   = m4_switch_lula,
    "Switch—Others" = m4_switch_others,
    "Eval—Lula"     = m4_eval_lula,
    "Eval—Others"   = m4_eval_others
  ),
  caption          = "Alternative Network Volatility Measure: Proportion of New Wave 5 Discussants (Model 3 Specification).",
  caption.above    = TRUE,
  label            = "tab:volatility_alt",
  custom.coef.map  = vol_coef_list,
  include.bic      = FALSE,
  include.deviance = FALSE,
  dcolumn          = FALSE,
  file             = "tables/table_volatility_alt.tex"
)
add_minipage_note(
  "tables/table_volatility_alt.tex",
  paste0(
    "Model 3 specification estimated separately for Lula and Other voters. ",
    "The network volatility measure is replaced by Prop. New Discussants$_{t}$",
    "the proportion of Wave 5 discussants not mentioned by the respondent in Wave 3, ",
    "capturing network turnover via discussant replacement rather than slot-level change. ",
    "Set to missing for respondents who named four discussants in Wave 5 (4th slot not tracked). ",
    "Switching models estimated via logit; performance evaluation models estimated via OLS."
  )
)
# Saved: tables/table_volatility_alt.tex


# ======================================================================#
# CHECK 5: Personality / Social Behavior Robustness (Mondak et al.) ------
# Source: Reviewer 2                                                     #
#                                                                        #
# Concern: personality traits (agreeableness, extraversion) may         #
# independently shape who people discuss politics with, creating a       #
# self-selection problem. Fix: add social behavior controls to M3 and   #
# verify the main disagreement coefficient is substantively unchanged.  #
#                                                                        #
# Controls added:                                                        #
#   conv_freq_w3        — avg. conversation frequency (1–4), W3         #
#   conv_freq_w5        — avg. conversation frequency (1–4), W5         #
#   persuade_others_w3  — tried to persuade others (0/1), W3            #
#   trust_strangers_w5  — trust in strangers (1–4), W5                  #
#                                                                        #
# Split-sample logit models mirror tab:switching. Interactive           #
# specification (all predictors x vote_lula) used for AIC/PCP fit      #
# comparison against the base M3 (m3a_fit from candidate_switching.R). #
# ======================================================================#

personality_controls <- c("conv_freq_w3", "conv_freq_w5", "persuade_others_w3", "trust_strangers_w5")

# M3 + personality controls for switch1 (includes lula_eval_w5 as predictor)
m3_pers <- c(m3_vars, personality_controls)

# --- Split-sample logit models (mirrors tab:switching) ---------------#
m5_switch_lula   <- glm(reformulate(m3_pers, "switch1"), binomial("logit"),
                        data = subset(dat, vote_lula == "Lula"))
m5_switch_others <- glm(reformulate(m3_pers, "switch1"), binomial("logit"),
                        data = subset(dat, vote_lula == "Other"))

nobs(m5_switch_lula); nobs(m5_switch_others)

# Coefficient labels for personality controls
pers_coef_list <- modifyList(
  coef_list,
  list(
    "conv_freq_w3"        = "Conv. Frequency$_{t-1}$",
    "conv_freq_w5"        = "Conv. Frequency$_{t}$",
    "persuade_others_w3"  = "Tried to Persuade Others$_{t-1}$",
    "trust_strangers_w5"  = "Trust in Strangers$_{t}$"
  )
)

# --- lula_eval_w5 models (OLS) ---------------------------------------#
m3_pers_eval <- c(setdiff(m3_vars, "lula_eval_w5"), personality_controls)

m5_eval_lula   <- lm(reformulate(m3_pers_eval, "lula_eval_w5"),
                     data = subset(dat, vote_lula == "Lula"))
m5_eval_others <- lm(reformulate(m3_pers_eval, "lula_eval_w5"),
                     data = subset(dat, vote_lula == "Other"))

nobs(m5_eval_lula); nobs(m5_eval_others)

screenreg(
  list(
    "Switch—Lula"   = m5_switch_lula,
    "Switch—Others" = m5_switch_others,
    "Eval—Lula"     = m5_eval_lula,
    "Eval—Others"   = m5_eval_others
  ),
  custom.coef.map = pers_coef_list,
  caption         = "CHECK 5: M3 + Social Behavior Controls"
)

# --- Interactive specification (switching + evals) -------------------#
# All M3 + personality predictors interacted with vote_lula; one model per DV.

m5a_switch_rhs <- paste0("(", paste(m3_pers, collapse = " + "), ") * factor(vote_lula)")
m5a_switch     <- glm(reformulate(m5a_switch_rhs, "switch1"), binomial("logit"), data = dat)

m5a_eval_rhs   <- paste0("(", paste(m3_pers_eval, collapse = " + "), ") * factor(vote_lula)")
m5a_eval       <- lm(reformulate(m5a_eval_rhs, "lula_eval_w5"), data = dat)

summary(m5a_eval)
nobs(m5a_switch); nobs(m5a_eval)
performance(m5a_eval)
performance_pcp(m5a_switch, method = "Gelman-Hill")

# --- LaTeX table (mirrors tab:switching style) -----------------------#

texreg(
  list(
    "Lula Voters"  = m5_switch_lula,
    "Other Voters" = m5_switch_others,
    "Lula Voters"  = m5_eval_lula,
    "Other Voters" = m5_eval_others
  ),
  caption          = "Candidate switching and performance evaluation models with social behavior controls added to the Model 3 specification.",
  caption.above    = TRUE,
  label            = "tab:pers_controls",
  custom.coef.map  = pers_coef_list,
  include.bic      = FALSE,
  include.deviance = FALSE,
  include.loglik   = FALSE,
  include.rsquared = FALSE,
  include.adjrs    = FALSE,
  dcolumn          = FALSE,
  file             = "tables/table_pers_controls.tex"
)
add_minipage_note(
  "tables/table_pers_controls.tex",
  paste0(
    "Model 3 specification with social behavior controls added. ",
    "Switching models (columns 1--2) are logit; evaluation models (columns 3--4) are OLS. ",
    "Estimated separately for Lula and Other voters."
  )
)
# Saved: tables/table_pers_controls.tex


# ======================================================================#
# CHECK 6: Mediation with Lagged Attitude Toward Lula (Wave 3) ---------
# Source: Reviewer 1 (temporal precedence concern)
#
# Adds v41a_thermlula3 (feeling thermometer toward Lula, Wave 3, 1–6)
#
# Both stage models and the mediation estimate are re-run; results are
# presented alongside main-analysis counterparts for comparison.
# ======================================================================#

med6_df <- dat |>
  dplyr::select(switch1, prop_disagree_w5a, prop_disagree_w3a, n_discuss_w5,
                n_discuss_w3, het_w5, het_w3, net_volatility,
                pid_yes_w3, pid_yes_w5, lula_eval_w5,
                media_w3, knowledge_w3, city5, vote_lula,
                lula_therm_w3) |>
  na.omit() |>
  filter(vote_lula == "Lula")

# Stage 1: disagreement -> performance evaluation (+ lagged thermometer)
eval_fit6 <- lm(lula_eval_w5 ~ prop_disagree_w5a + prop_disagree_w3a +
                  n_discuss_w5 + n_discuss_w3 + het_w5 + het_w3 +
                  net_volatility + pid_yes_w3 + pid_yes_w5 +
                  media_w3 + knowledge_w3 + lula_therm_w3 + factor(city5),
                data = med6_df)

# Stage 2: evaluation + disagreement -> switching (LPM)
switch_fit6_lm <- lm(switch1 ~ lula_eval_w5 + prop_disagree_w5a + prop_disagree_w3a +
                       n_discuss_w5 + n_discuss_w3 + het_w5 + het_w3 +
                       net_volatility + pid_yes_w3 + pid_yes_w5 +
                       media_w3 + knowledge_w3 + lula_therm_w3 + factor(city5),
                     data = med6_df)

# Stage 2: evaluation + disagreement -> switching (Probit)
switch_fit6_prob <- glm(switch1 ~ lula_eval_w5 + prop_disagree_w5a + prop_disagree_w3a +
                          n_discuss_w5 + n_discuss_w3 + het_w5 + het_w3 +
                          net_volatility + pid_yes_w3 + pid_yes_w5 +
                          media_w3 + knowledge_w3 + lula_therm_w3 + factor(city5),
                        data = med6_df, family = binomial("probit"))

# Mediation (0.33-point increase, consistent with main analysis)
med6_lm <- mediation::mediate(
  model.m  = eval_fit6,
  model.y  = switch_fit6_lm,
  treat    = "prop_disagree_w5a",
  mediator = "lula_eval_w5",
  control.value = 0, treat.value = 0.33
)

med6_prob <- mediation::mediate(
  model.m  = eval_fit6,
  model.y  = switch_fit6_prob,
  treat    = "prop_disagree_w5a",
  mediator = "lula_eval_w5",
  control.value = 0, treat.value = 0.33
)

summary(med6_lm)
summary(med6_prob)

# Coefficient labels (add thermometer to shared list)
med6_coef_list <- modifyList(
  coef_list,
  list("lula_therm_w3" = "Lula Thermometer$_{t-1}$")
)

# Regression table: stage 1 and stage 2 models
texreg(
  list(
    "Perf. Eval. (M1)"    = eval_fit6,
    "Switched—LPM (M2)"   = switch_fit6_lm,
    "Switched—Probit (M2)" = switch_fit6_prob
  ),
  caption         = "Mediation Models with Lagged Attitude Toward Lula (Wave 3) as Control (Lula Voters).",
  caption.above   = TRUE,
  label           = "tab:med_lula_therm",
  custom.coef.map = med6_coef_list,
  include.bic     = FALSE,
  include.deviance = FALSE,
  dcolumn         = FALSE,
  file            = "tables/table_med_lula_therm.tex"
)
add_minipage_note(
  "tables/table_med_lula_therm.tex",
  paste0(
    "Sample restricted to respondents who voted for Lula in Wave 3. ",
    "M1 predicts the performance evaluation index via OLS. M2 predicts candidate switching ",
    "via LPM (column 2) and probit (column 3). All models add the Wave 3 feeling thermometer ",
    "toward Lula (1--6 scale) as a control for pre-existing attitudes. ",
    "Mediation results (probit): ACME = ",
    sprintf("%.3f", med6_prob$d.avg),
    ", 95\\%% CI [",
    sprintf("%.3f", med6_prob$d.avg.ci[1]), ", ",
    sprintf("%.3f", med6_prob$d.avg.ci[2]),
    "], p = ", sprintf("%.3f", med6_prob$d.avg.p), "."
  )
)
# Saved: tables/table_med_lula_therm.tex


summary(dat$lula_therm_w3)
