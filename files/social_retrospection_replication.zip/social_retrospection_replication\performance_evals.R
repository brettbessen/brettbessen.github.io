# Analysis of Performance Evals
## Runs Models and Prints to Latex (Appendix)
## Plots Predicted Values 
## Runs and Plots Models by Type of Eval

# Setup -------------------------------------------- 

if (!require("pacman")) install.packages("pacman")

pacman::p_load(haven, tidyverse, ggplot2, gmodels, ggpubr, ggrepel,
               stargazer, performance, marginaleffects, ggsci, 
               nnet, dotwhisker, broom, mediation, conflicted, arm, psych, texreg,
               sensemakr, gridGraphics, Hmisc, lubridate, purrr, broom)

conflicts_prefer(dplyr::select)
conflicts_prefer(dplyr::filter)

# Load Data 
dat <- read_rds("analysis_dat.Rds")

# Transition Models ----------------------

## Model 1 ----------------------------------------

# Model 1 IVs
m1_vars <- c("prop_disagree_w5a", "prop_disagree_w3a", 
             "factor(city5)")

# Model 1 - Lula
m1_lula <- lm(
  reformulate(m1_vars, response = "lula_eval_w5"),
  data = subset(dat, vote_lula == "Lula")
)

# Model 1 - Others
m1_others <- lm(
  reformulate(m1_vars, response = "lula_eval_w5"), 
  data = subset(dat, vote_lula == "Other")
)

## Model 2 -----------------------------------

# Model 2 IVs
m2_vars <- union(m1_vars, c("n_discuss_w5", "n_discuss_w3", "het_w5", "het_w3",
                            "net_volatility", "pid_yes_w5", "pid_yes_w3"))

# Model 2 -- Lula Voters
m2_lula <- lm(
  reformulate(m2_vars, response = "lula_eval_w5"),
  data = subset(dat, vote_lula == "Lula")
)

# Model 3 -- Other Voters 
m2_others <- lm(
  reformulate(m2_vars, response = "lula_eval_w5"),
  data = subset(dat, vote_lula == "Other")
)


## Model 3 ---------------------------------------------------

# Model 3 IVs
m3_vars <- union(m2_vars, c("media_w3", "knowledge_w3"))

# Model 3 -- Lula Voters
m3_lula <- lm(
  reformulate(m3_vars, response = "lula_eval_w5"),
  data = subset(dat, vote_lula == "Lula")
)

# Model 3 -- Other Voters 
m3_others <- lm(
  reformulate(m3_vars, response = "lula_eval_w5"),
  data = subset(dat, vote_lula == "Other")
)

## Out to Latex ---------------------------------------------

texreg(m3_lula)

coef_list <- list(
  "prop_disagree_w5a" = "Prop. Disagreeing$_{t}$",
  "prop_disagree_w3a" = "Prop. Disagreeing$_{t-1}$",
  "n_discuss_w5"  = "Num. Disscussants$_{t}$",
  "n_discuss_w3" = "Num. Disscussants$_{t-1}$",
  "het_w5"  =  "Network Diversity$_{t}$",
  "het_w3" =  "Network Diversity$_{t-1}$", 
  "net_volatility" = "Network Change",
  "pid_yes_w51" = "Party Identity$_{t}$", 
  "pid_yes_w31" = "Party Identity$_{t-1}$", 
  "media_w3" = "Media Consumption$_{t-1}$",
  "knowledge_w3" = "Political Knowledge$_{t-1}$",
  "(Intercept)" = "Intercept"
)


capt <- "Models of Lula Performance Evalations.  The dependent variable ranges from 0 to 10."

texreg(list("Lula" = m1_lula, "Other" = m1_others, 
            "Lula" = m2_lula, "Other" = m2_others,
            "Lula" = m3_lula, "Other" = m3_others),
       caption = capt,
       caption.above = T,
       label = "tab:switching",
       custom.coef.map = coef_list, 
       include.bic = F,
       include.deviance = F, 
       dcolumn = F)


# Equivalent interaction models ------------------------

## Model 1a -------------------------------------

m1a_rhs <- paste0("(", paste(m1_vars, collapse = " + "), ") * factor(vote_lula)")

m1a_fit <- lm(
  reformulate(m1a_rhs, response = "lula_eval_w5"),
  data = dat
)

glance(m1a_fit) 
nobs(m1a_fit)

## Model 2a ---------------------------------------------

m2a_rhs <- paste0("(", paste(m2_vars, collapse = " + "), ") * factor(vote_lula)")


m2a_fit <- lm(
  reformulate(m2a_rhs, response = "lula_eval_w5"),
  data = dat
)

nobs(m2a_fit)
glance(m2a_fit)

## Model 3a ---------------------------------------------

m3a_rhs <- paste0("(", paste(m3_vars, collapse = " + "), ") * factor(vote_lula)")

m3a_fit <- lm(
  reformulate(m3a_rhs, response = "lula_eval_w5"),
  data = dat
)


nobs(m3a_fit)
glance(m3a_fit)

summary(m3a_fit)

# Plot Predictions --------------------------

preds1 <- predictions(m3a_fit, newdata = datagrid(
  prop_disagree_w5a = seq(0, 1, .1),
  vote_lula = c("Lula", "Other")
))

preds1 <- preds1 |> 
  dplyr::select(prop_disagree_w5a, vote_lula, estimate, 
                conf.low, conf.high) |> 
  mutate(vote_lula = case_match(vote_lula,
                                "Lula" ~ "Lula Voter (Oct. 2002)",
                                "Other" ~ "Opposition Voter (Oct. 2002)"))


ggplot(preds1, aes(prop_disagree_w5a, estimate)) +
  geom_line() + 
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = .20, color = NA) +
  facet_grid(~ vote_lula) +
  labs(y = "Performance Evaluation", 
       x = "Network Disagreement", 
       title = "Network Disagreement and Evaluations of Lula's  Performance") +
  theme_pubr() +
  scale_y_continuous(limits = c(2.4,5.1), breaks = seq(from = 2.5, to = 5.5, by = 0.5)) +
  theme(plot.title = element_text(hjust = .5),
        axis.title = element_text(face = "bold"))


# ggsave("figs/performance_preds.pdf", height = 4, width = 6)
ggsave("figs/performance_preds.tif", height = 4, width = 7, dpi = 300)


## Interpretation -----------------------------------------

preds_evals <-  predictions(m3a_fit, 
                          newdata = datagrid(prop_disagree_w5a = c(0, 0.33),
                                             vote_lula = c("Lula", "Other")
                          ))  |> 
  dplyr::select(vote_lula, prop_disagree_w5a, estimate) |> 
  arrange(vote_lula)

tidy(preds_evals)


# Alternative Specification with Prop Lula --------------------------------

alternative_vars <- union(
  # drop prop_disagree from m3 vars
  setdiff(m3_vars, c("prop_disagree_w5a", "prop_disagree_w3a")), 
  # add prop Lula
  c("prop_lula_w3", "prop_lula_w5") 
)


m3_alt_others <- lm(
  reformulate(alternative_vars, response = "lula_eval_w5"),
  data = subset(dat, vote_lula == "Other")
)

summary(m3_alt_others)


# Plot Effect of Disagreement by Issue  --------------------------------


rhs <- c(
  "prop_disagree_w5a", "prop_disagree_w3a",
  "n_discuss_w5", "n_discuss_w3",
  "het_w5", "het_w3",
  "net_volatility",
  "pid_yes_w5", "pid_yes_w3",
  "factor(city5)",
  "media_w3", "knowledge_w3"
)


dvs <- c(
  "corrupt_therm_w5",
  "inflation_therm_w5",
  "jobs_therm_w5",
  "crime_therm_w5"
)


models <- map(
  dvs,
  ~ lm(
    reformulate(rhs, response = .x),
    data = subset(dat, vote_lula == "Lula")
  )
)


stargazer(models, type = "text")

