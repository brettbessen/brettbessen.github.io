
* Note: needs copydesc
*ssc install copydesc

* NOTE (replication package): the original script used an absolute `cd` path.
* This copy assumes Stata's working directory is already set to this
* replication folder (e.g., via File > Change Working Directory, or `cd` at
* the command line) and that TwoCityPanelStudy.dta has been downloaded there
* per the README before running.

*Data are panel data where the units are respondent waves
use "TwoCityPanelStudy.dta", clear


*Keep variables we'll use
keep id wave whennew city date  v22c_presvote ///
	v74_disc1named v75_disc2named v76_disc3named v77_disc4named ///
	v74b_disc1relate v75b_disc2relate v76b_disc3relate v77b_disc4relate ///
	v74c_disc1presvote v75c_disc2presvote v76c_disc3presvote v77c_disc4presvote ///
	v43a_pidyesorno v7b2fq_mediatv2choicefreq ///
	v79a_thermlulagovcorruption v79b_thermlulagovinflation ///
	v79d_thermlulagovjobs v79e_thermlulagovcrime ///
	s14b_know2vicepres s14c_know3fhcparty s14d_know4mercosul ///
	v16c_converseworkorschool v16e_conversefriends v16g_conversefamily ///
	v39a_persuadetoothersyesorno v21e_truststrangers v41a_thermlula



* Reshape so units are individuals:
qui: reshape wide city date v22c_presvote ///
	v74_disc1named v75_disc2named v76_disc3named v77_disc4named ///
	v74b_disc1relate v75b_disc2relate v76b_disc3relate v77b_disc4relate ///
	v74c_disc1presvote v75c_disc2presvote v76c_disc3presvote v77c_disc4presvote ///
	v43a_pidyesorno v7b2fq_mediatv2choicefreq ///
	v79a_thermlulagovcorruption v79b_thermlulagovinflation ///
	v79d_thermlulagovjobs v79e_thermlulagovcrime ///
	s14b_know2vicepres s14c_know3fhcparty s14d_know4mercosul ///
	v16c_converseworkorschool v16e_conversefriends v16g_conversefamily ///
	v39a_persuadetoothersyesorno v21e_truststrangers v41a_thermlula, ///
	i(id) j(wave)


* Add discussant retention data
joinby id using "brazil_discussant_retention.dta", unmatched(master)



*********RECODE NETWORK DATA*****************

* Note: New discussant list in waves 2 and 5
* Respondents are asked about same discussants between these waves
* I.e., In wave 3, respondents are asked about discussants named during wave 2

*Discussants named - Wave 2
gen d1_w2 = v74_disc1named2
gen d2_w2 = v75_disc2named2
gen d3_w2 = v76_disc3named2
gen d4_w2 = v77_disc4named2

*Discussants named - Wave 5
gen d1_w5 = v74_disc1named5
gen d2_w5 = v75_disc2named5
gen d3_w5 = v76_disc3named5
gen d4_w5 = v77_disc4named5

*Number of Named Discussants - Wave 2
gen n_discuss_w2 = .
replace n_discuss_w2 = d1_w2 + d2_w2 + d3_w2 + d4_w2
replace n_discuss_w2 = . if whennew == 2  // fresh wave 2 respondents didn't get the name generator

*Number of Named Discussants - Wave 5
gen n_discuss_w5 = .
replace n_discuss_w5 = d1_w5 + d2_w5 + d3_w5 + d4_w5

*Push forward to network measure in next wave
*Discussant list was generated in wave 2; respondents have the same discussants in wave 3
gen n_discuss_w3 = n_discuss_w2

* Drop temporary vars (named indicators no longer needed; counts now in n_discuss_w*)
drop d1_w2 d2_w2 d3_w2 d4_w2 d1_w5 d2_w5 d3_w5 d4_w5 n_discuss_w2 whennew
drop v74_disc1named* v75_disc2named* v76_disc3named* v77_disc4named*



***** PRESIDENTIAL VOTE CHOICE *****

* Code vote choice for egos and alters
* Recode don't know, won't vote, NR == .
* 16. Outro, 17. Nenhum (NÃO LER) Non-voters in waves 3 & 6., 18. NS, 19. NR
* Only generate for waves 3 and 5 (used for disagree, heterogeneity, volatility, and switching DV)

foreach i in 3 5 {

	*EGOS:
	recode v22c_presvote`i' (17 18 19 = .), gen(pres_vote_w`i')
		copydesc v22c_presvote`i' pres_vote_w`i'

	*ALTERS:
	* Note: raw v74c_disc1presvote3 and v74c_disc1presvote5 retained in output
	* for robustness.R Check 2 (alternative disagreement measure excluding DK alters)
	recode v74c_disc1presvote`i' (17 18 19 99 = .), gen(pres_voteD1_w`i')
		copydesc v74c_disc1presvote`i' pres_voteD1_w`i'

	recode v75c_disc2presvote`i' (17 18 19 99 = .), gen(pres_voteD2_w`i')
		copydesc v75c_disc2presvote`i' pres_voteD2_w`i'

	recode v76c_disc3presvote`i' (17 18 19 99 = .), gen(pres_voteD3_w`i')
		copydesc v76c_disc3presvote`i' pres_voteD3_w`i'

	recode v77c_disc4presvote`i' (17 18 19 99 = .), gen(pres_voteD4_w`i')
		copydesc v77c_disc4presvote`i' pres_voteD4_w`i'

}

* Drop raw disc presvote waves not needed in output (keep waves 3 and 5 for robustness.R)
drop v74c_disc1presvote1 v74c_disc1presvote2 v74c_disc1presvote4 v74c_disc1presvote6
drop v75c_disc2presvote1 v75c_disc2presvote2 v75c_disc2presvote4 v75c_disc2presvote6
drop v76c_disc3presvote1 v76c_disc3presvote2 v76c_disc3presvote4 v76c_disc3presvote6
drop v77c_disc4presvote1 v77c_disc4presvote2 v77c_disc4presvote4 v77c_disc4presvote6

* Drop relate waves not needed in output
* Waves 2 and 5 retained for robustness.R Check 4b (fuzzy-matched volatility)
drop v74b_disc1relate1 v74b_disc1relate3 v74b_disc1relate4 v74b_disc1relate6
drop v75b_disc2relate1 v75b_disc2relate3 v75b_disc2relate4 v75b_disc2relate6
drop v76b_disc3relate1 v76b_disc3relate3 v76b_disc3relate4 v76b_disc3relate6
drop v77b_disc4relate1 v77b_disc4relate3 v77b_disc4relate4 v77b_disc4relate6



*****NETWORK DISAGREEMENT*******

*Tag alters who disagree, wave 3
forvalues i = 1(1)4 {

	gen disagreeD`i'_w3 = .
	replace disagreeD`i'_w3 = 0 if pres_voteD`i'_w3 == pres_vote_w3 & pres_voteD`i'_w3 != .
	replace disagreeD`i'_w3 = 1  if pres_voteD`i'_w3 != pres_vote_w3 ///
		& pres_voteD`i'_w3 != . & pres_vote_w3 != .
}

*Tag alters who disagree, wave 5
forvalues i = 1(1)4 {

	gen disagreeD`i'_w5 = .
	replace disagreeD`i'_w5 = 0 if pres_voteD`i'_w5 == pres_vote_w5 & pres_voteD`i'_w5 != .
	replace disagreeD`i'_w5 = 1  if pres_voteD`i'_w5 != pres_vote_w5 ///
		& pres_voteD`i'_w5 != . & pres_vote_w5 != .
}

*Number of disagreeing discussion partners
**** This adds across rows, leaving new variable missing if all values are missing
**** IMPORTANT: This counts named discussants with unknown presidential vote as agreeing

*Wave 3
egen n_disagree_w3 = rowtotal(disagreeD1_w3 disagreeD2_w3 disagreeD3_w3 disagreeD4_w3), missing

*Wave 5
egen n_disagree_w5 = rowtotal(disagreeD1_w5 disagreeD2_w5 disagreeD3_w5 disagreeD4_w5), missing

*Proportion of alters who disagree:

*Wave 3
gen prop_disagree_w3 = .
replace prop_disagree_w3 = n_disagree_w3/n_discuss_w3
la var prop_disagree_w3 "Proportion Disagree (zero discussants = missing)"

*Wave 5
gen prop_disagree_w5 = .
replace prop_disagree_w5 = n_disagree_w5/n_discuss_w5
la var prop_disagree_w5 "Proportion Disagree (zero discussants = missing)"

*One person names 3 discussants and disagrees with 4 — data entry error
drop if id == 22151


*Include people with zero discussants (coded 0, not missing)

*Wave 3
gen prop_disagree_w3a = prop_disagree_w3
replace prop_disagree_w3a = 0 if n_discuss_w3 == 0
	la var prop_disagree_w3a "Proportion disagree - no discussants are zeros"

*Wave 5
gen prop_disagree_w5a = prop_disagree_w5
replace prop_disagree_w5a = 0 if n_discuss_w5 == 0
	la var prop_disagree_w5a " Proportion disagree - no discussants are zeros"

* Drop intermediate disagree indicators and non-"a" proportions
drop disagreeD1_w3 disagreeD2_w3 disagreeD3_w3 disagreeD4_w3
drop disagreeD1_w5 disagreeD2_w5 disagreeD3_w5 disagreeD4_w5
drop n_disagree_w3 n_disagree_w5 prop_disagree_w3 prop_disagree_w5



**** NETWORK VOLATILITY MEASURE ********

forvalues i = 1(1)4 { // looping over alters

	gen D`i'changed = 0 // zero, even if no discussant
	replace D`i'changed = 1 if pres_voteD`i'_w3 != pres_voteD`i'_w5  // code 1 if discussant changed candidates between waves 3 and 5
	replace D`i'changed = 0 if pres_voteD`i'_w3 == 4 & pres_voteD`i'_w5 == 10 // code Serra --> Alckmin voters as stable
	*replace D`i'changed = 0  if pres_voteD`i'_w3 == . | pres_voteD`i'_w5 == .  // don't count don't knows as volatility

}

egen total_alters_change = rowtotal(D1changed D2changed D3changed D4changed)
gen net_volatility = total_alters_change/4 // total switches over maximum possible number of discussants

drop D1changed D2changed D3changed D4changed total_alters_change


*** ALTERNATIVE VOLATILITY MEASURE ***
forvalues i = 1(1)3 {
	
	gen new_d`i' = .
	replace new_d`i' = 0 if discussant`i' != .  // discussant not missing
	replace new_d`i' = 1 if discussant`i' == 0  // new discussant 
	
}

* Total number of new discussants
egen num_new = rowtotal(new_d1 new_d2 new_d3), missing

* Proportion of new discussants 
gen prop_new_w5 = .
replace prop_new_w5 = num_new/n_discuss_w5
replace prop_new_w5 = . if n_discuss_w5 == 4



**** NETWORK HETEROGENEITY MEASURE
* One minus the sum of the squared proportion of alters belonging to each group

**Wave 3**

* Dummy for each group among alters
forvalues i = 1(1)4 { // looping across alters

	recode pres_voteD`i'_w3 (1 = 1) (.=.) (else=0), gen(ciroD`i'_w3)   // ciro
	recode pres_voteD`i'_w3 (2 = 1) (.=.) (else=0), gen(lulaD`i'_w3)   // lula
	recode pres_voteD`i'_w3 (4 = 1) (.=.) (else=0), gen(serraD`i'_w3)  // serra
	recode pres_voteD`i'_w3 (5 = 1) (.=.) (else=0), gen(garoD`i'_w3)   // garotinho
	recode pres_voteD`i'_w3 (6 = 1) (.=.) (else=0), gen(itamD`i'_w3)   // itamar
	recode pres_voteD`i'_w3 (7 = 1) (.=.) (else=0), gen(joseD`i'_w3)   // jose maria
	recode pres_voteD`i'_w3 (8 = 1) (.=.) (else=0), gen(ruiD`i'_w3)    // rui
	recode pres_voteD`i'_w3 (16 = 1) (.=.) (else=0), gen(otherD`i'_w3) // other

}

* Total opinionated discussants wave 3
egen opinionated_w3 = rowtotal(ciroD*_w3 lulaD*_w3 serraD*_w3 garoD*_w3 itamD*_w3 joseD*_w3 ruiD*_w3 otherD*_w3)

* Total per candidate group
egen sum_ciro_w3  = rowtotal(ciroD*_w3)
egen sum_lula_w3  = rowtotal(lulaD*_w3)
egen sum_serra_w3 = rowtotal(serraD*_w3)
egen sum_garo_w3  = rowtotal(garoD*_w3)
egen sum_itmar_w3 = rowtotal(itamD*_w3)
egen sum_jose_w3  = rowtotal(joseD*_w3)
egen sum_rui_w3   = rowtotal(ruiD*_w3)

* Proportion of alters in each candidate group
gen prop_ciro_w3  = sum_ciro_w3/opinionated_w3
gen prop_lula_w3  = sum_lula_w3/opinionated_w3   // retained: used in R (alternative spec, descriptives)
gen prop_serra_w3 = sum_serra_w3/opinionated_w3
gen prop_garo_w3  = sum_garo_w3/opinionated_w3
gen prop_itmar_w3 = sum_itmar_w3/opinionated_w3
gen prop_jose_w3  = sum_jose_w3/opinionated_w3
gen prop_rui_w3   = sum_rui_w3/opinionated_w3

* FLAG: Negative values of het_w3 were noted in the original code (comment: "why are some values negative?")
* Negative values imply opinionated_w3 > 4 — more opinionated alters counted than possible.
* Likely cause: miscounting when alter vote codes outside the recode rules are present.
* Investigate before using het_w3 in analysis.
gen het_w3 = 1 - (prop_ciro_w3^2 + prop_lula_w3^2 + prop_serra_w3^2 + prop_garo_w3^2 + prop_itmar_w3^2 + prop_jose_w3^2 + prop_rui_w3^2)
replace het_w3 = 0 if opinionated_w3 == 0 // code those with no disagreeing discussants as zero

* Drop intermediates (keep prop_lula_w3 and het_w3 for downstream use)
drop ciroD*_w3 lulaD*_w3 serraD*_w3 garoD*_w3 itamD*_w3 joseD*_w3 ruiD*_w3 otherD*_w3
drop opinionated_w3
drop sum_ciro_w3 sum_lula_w3 sum_serra_w3 sum_garo_w3 sum_itmar_w3 sum_jose_w3 sum_rui_w3
drop prop_ciro_w3 prop_serra_w3 prop_garo_w3 prop_itmar_w3 prop_jose_w3 prop_rui_w3

* pres_voteD*_w3 now fully consumed — drop
drop pres_voteD1_w3 pres_voteD2_w3 pres_voteD3_w3 pres_voteD4_w3


** Wave 5 **

* Dummy for each group among alters
forvalues i = 1(1)4 { // looping across alters

	recode pres_voteD`i'_w5 (2 = 1) (.=.) (else=0), gen(lulaD`i'_w5)    // lula
	recode pres_voteD`i'_w5 (10 = 1) (.=.) (else=0), gen(alckminD`i'_w5) // alckmin
	recode pres_voteD`i'_w5 (11 = 1) (.=.) (else=0), gen(buarD`i'_w5)    // buarque
	recode pres_voteD`i'_w5 (12 = 1) (.=.) (else=0), gen(helenaD`i'_w5)  // heloisa helena
	recode pres_voteD`i'_w5 (13 = 1) (.=.) (else=0), gen(eyD`i'_w5)      // eymeal
	recode pres_voteD`i'_w5 (14 = 1) (.=.) (else=0), gen(bivarD`i'_w5)   // bivar
	recode pres_voteD`i'_w5 (16 = 1) (.=.) (else=0), gen(otherD`i'_w5)   // other

}

* Total opinionated discussants wave 5
egen opinionated_w5 = rowtotal(lulaD*_w5 alckminD*_w5 buarD*_w5 helenaD*_w5 eyD*_w5 bivarD*_w5 otherD*_w5)

* Total per candidate group
egen sum_lula_w5    = rowtotal(lulaD*_w5)
egen sum_alckmin_w5 = rowtotal(alckminD*_w5)
egen sum_buar_w5    = rowtotal(buarD*_w5)
egen sum_helena_w5  = rowtotal(helenaD*_w5)
egen sum_ey_w5      = rowtotal(eyD*_w5)
egen sum_bivar_w5   = rowtotal(bivarD*_w5)

* Proportion of alters in each candidate group
gen prop_lula_w5    = sum_lula_w5/opinionated_w5    // retained: used in R (alternative spec, descriptives)
gen prop_alckmin_w5 = sum_alckmin_w5/opinionated_w5
gen prop_buar_w5    = sum_buar_w5/opinionated_w5
gen prop_helena_w5  = sum_helena_w5/opinionated_w5
gen prop_ey_w5      = sum_ey_w5/opinionated_w5
gen prop_bivar_w5   = sum_bivar_w5/opinionated_w5

gen het_w5 = 1 - (prop_lula_w5^2 + prop_alckmin_w5^2 + prop_buar_w5^2 + prop_helena_w5^2 + prop_ey_w5^2 + prop_bivar_w5^2)
replace het_w5 = 0 if opinionated_w5 == 0 // code those with no disagreeing discussants as zero

* Drop intermediates (keep prop_lula_w5 and het_w5 for downstream use)
drop lulaD*_w5 alckminD*_w5 buarD*_w5 helenaD*_w5 eyD*_w5 bivarD*_w5 otherD*_w5
drop opinionated_w5
drop sum_lula_w5 sum_alckmin_w5 sum_buar_w5 sum_helena_w5 sum_ey_w5 sum_bivar_w5
drop prop_alckmin_w5 prop_buar_w5 prop_helena_w5 prop_ey_w5 prop_bivar_w5

* pres_voteD*_w5 now fully consumed — drop
drop pres_voteD1_w5 pres_voteD2_w5 pres_voteD3_w5 pres_voteD4_w5



****************DEPENDENT VARS***********************

** Switched Candidates Across Party Lines

gen switch1 = .
la var switch1 "Switched party support Oct 2002 to July 2006"

*Switch = 0
replace switch1 = 0 if pres_vote_w3 == pres_vote_w5 ///
	 & pres_vote_w3 != . & pres_vote_w5 != .

*Switch = 1
replace switch1 = 1 if pres_vote_w3 != pres_vote_w5 ///
	 & pres_vote_w3 != . & pres_vote_w5 != .

*Switch = 0 (PSDB --> PSDB, Serra --> Alckmin)
replace switch1 = 0 if pres_vote_w3 == 4 & pres_vote_w5 == 10
la var switch1 "Switched party support Oct 2002 to July 2006"


** Vote Lula Binary — Wave 3 only (used to split sample in R)
gen vote_lula_w3 = .
replace vote_lula_w3 = 1 if pres_vote_w3 == 2
replace vote_lula_w3 = 0 if pres_vote_w3 != 2 & pres_vote_w3 != .
la var vote_lula_w3 "Voted Lula Wave 3"



********INDEPENDENT VARS*********************************

foreach i in 1 2 3 4 5 6 {  // looping through waves

	*Party Identification
	recode v43a_pidyesorno`i' (2 = 0 "No") (8 9 = .), gen(pid_yes_w`i')
	la var pid_yes_w`i' "Do you sympathize w/ a particular party? W`i'"

	*Media Use (TV Watching Freq)
	recode v7b2fq_mediatv2choicefreq`i' (8 9 = .), gen(media_w`i')

	* Lula Government Performance Thermometers
	recode v79a_thermlulagovcorruption`i' (18 19 = .), gen(corrupt_therm_w`i')
	recode v79b_thermlulagovinflation`i'  (18 19 = .), gen(inflation_therm_w`i')
	recode v79d_thermlulagovjobs`i'        (18 19 = .), gen(jobs_therm_w`i')
	recode v79e_thermlulagovcrime`i'       (18 19 = .), gen(crime_therm_w`i')

	*Political Conversation Frequency
	recode v16c_converseworkorschool`i' (1 = 4) (2 = 3) (3 = 2) (4 = 1) (8 9 10 = .), gen(conv_freq_ws_w`i')
	recode v16e_conversefriends`i'      (1 = 4) (2 = 3) (3 = 2) (4 = 1) (8 9 10 = .), gen(conv_freq_friends_w`i')
	recode v16g_conversefamily`i'       (1 = 4) (2 = 3) (3 = 2) (4 = 1) (8 9 10 = .), gen(conv_freq_family_w`i')

}

* Drop wave-specific vars not needed in output
* pid_yes: only waves 3 and 5 used
drop pid_yes_w1 pid_yes_w2 pid_yes_w4 pid_yes_w6
* media: only wave 3 used
drop media_w1 media_w2 media_w4 media_w5 media_w6
* thermometers: only wave 5 used (for lula_eval_w5 index in R)
drop corrupt_therm_w1 corrupt_therm_w2 corrupt_therm_w3 corrupt_therm_w4 corrupt_therm_w6
drop inflation_therm_w1 inflation_therm_w2 inflation_therm_w3 inflation_therm_w4 inflation_therm_w6
drop jobs_therm_w1 jobs_therm_w2 jobs_therm_w3 jobs_therm_w4 jobs_therm_w6
drop crime_therm_w1 crime_therm_w2 crime_therm_w3 crime_therm_w4 crime_therm_w6

* Drop raw source vars (no longer needed)
drop v43a_pidyesorno* v7b2fq_mediatv2choicefreq*
drop v79a_thermlulagovcorruption* v79b_thermlulagovinflation*
drop v79d_thermlulagovjobs* v79e_thermlulagovcrime*


* Political Conversation Frequency composites (waves 3 and 5)
* Used in robustness.R Check 5 (social behavior / personality robustness)
gen conv_freq_w3 = (conv_freq_ws_w3 + conv_freq_friends_w3 + conv_freq_family_w3)/3
gen conv_freq_w5 = (conv_freq_ws_w5 + conv_freq_friends_w5 + conv_freq_family_w5)/3

* Drop sub-item conversation frequency vars
drop conv_freq_ws_w* conv_freq_friends_w* conv_freq_family_w*
drop v16c_converseworkorschool* v16e_conversefriends* v16g_conversefamily*


* Tried to persuade others — Wave 3 (robustness.R Check 5)
recode v39a_persuadetoothersyesorno3 (2=0)(8 9=.), gen(persuade_others_w3)
la var persuade_others_w3 "Tried to persuade others, W3 (1=Yes)"
drop v39a_persuadetoothersyesorno*

* Trust in strangers — Wave 5 (robustness.R Check 5)
recode v21e_truststrangers5 (1=4)(2=3)(3=2)(4=1)(8 9=.), gen(trust_strangers_w5)
la var trust_strangers_w5 "Trust in strangers, W5; higher=more trust"
drop v21e_truststrangers*

* Feeling thermometer toward Lula — Wave 3 
recode v41a_thermlula3 (8 9 = .), gen(lula_therm_w3)
la var lula_therm_w3 "Feeling thermometer toward Lula, W3 (1–6)"
drop v41a_thermlula*


* Political Knowledge — Wave 3
gen know1_w3 = s14b_know2vicepres3
recode know1_w3 (2 = 1) (9 = .) (nonm = 0)

gen know2_w3 = s14c_know3fhcparty3
recode know2_w3 (3 = 1) (9 = .) (nonm = 0)

gen know3_w3 = s14d_know4mercosul3
recode know3_w3 (2 = 1) (9 = .) (nonm = 0)

gen knowledge_w3 = know1_w3 + know2_w3 + know3_w3

drop know1_w3 know2_w3 know3_w3
drop s14b_know2vicepres* s14c_know3fhcparty* s14d_know4mercosul*


* Drop v22c_presvote waves not needed in output
* Waves 5 and 6 used directly in multinomial_and_mediation.R
drop v22c_presvote1 v22c_presvote2 v22c_presvote3 v22c_presvote4



order id date3 date5 city5 switch1 net_volatility het_w3 het_w5 ///
	vote_lula_w3 n_discuss_w3 n_discuss_w5 ///
	prop_disagree_w3a prop_disagree_w5a prop_lula_w3 prop_lula_w5 ///
	knowledge_w3 media_w3 pid_yes_w3 pid_yes_w5 ///
	corrupt_therm_w5 inflation_therm_w5 jobs_therm_w5 crime_therm_w5 ///
	pres_vote_w3 pres_vote_w5 v22c_presvote5 v22c_presvote6 ///
	conv_freq_w3 conv_freq_w5 persuade_others_w3 trust_strangers_w5 ///
	prop_new_w5 lula_therm_w3

* Save a dta
save "brazil_net_wide.dta", replace

* Save a version without variable labels
preserve

label drop _all

export delimited "brazilnet_data_v2", replace

restore
